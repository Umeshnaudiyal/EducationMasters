import AdmitCard from './admitCard.model.js';
import Advert from './advert.model.js';
import Blog from './blog.model.js';
import Category from './category.model.js';
import Country from './country.model.js';
import Course from './course.model.js';
import Department from './department.model.js';
import District from './district.model.js';
import Exam from './exam.model.js';
import Facility from './facility.model.js';
import Institute from './institute.model.js';
import Job from './job.model.js';
import Media from './media.model.js';
import Question from './question.model.js';
import Result from './result.model.js';
import State from './state.model.js';
import Subject from './subject.model.js';
import Subscriber from './subscriber.model.js';
import Tag from './tag.model.js';
import Topic from './topic.model.js';
import TopicGroup from './topicGroup.model.js';
import User from './user.model.js';
import UserLog from './userLog.model.js';
import MockTestSeries from './mockTestSeries.model.js';
import MockTest from './mockTest.model.js';
import MockTestPlan from './mockTestPlan.model.js';
import MockTestAttempt from './mockTestAttempt.model.js';
import Payment from './payment.model.js';
import StickyNote from './stickyNote.model.js';

export {
  AdmitCard,
  Advert,
  Blog,
  Category,
  Country,
  Course,
  Department,
  District,
  Exam,
  Facility,
  Institute,
  Job,
  Media,
  Question,
  Result,
  State,
  Subject,
  Subscriber,
  Tag,
  Topic,
  TopicGroup,
  User,
  UserLog,
  MockTestSeries,
  MockTest,
  MockTestPlan,
  MockTestAttempt,
  Payment,
  StickyNote,
};
