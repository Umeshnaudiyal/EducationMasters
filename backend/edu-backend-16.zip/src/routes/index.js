import express from 'express';
import admitCardRoutes from './admitCard.routes.js';
import authRoutes from './auth.routes.js';
import userRoutes from './user.routes.js';
import blogRoutes from './blog.routes.js';
import jobRoutes from './job.routes.js';
import instituteRoutes from './institute.routes.js';
import courseRoutes from './course.routes.js';
import facilityRoutes from './facility.routes.js';
import mediaRoutes from './media.routes.js';
import statsRoutes from './stats.routes.js';
import questionRoutes from './question.routes.js';
import categoryRoutes from './category.routes.js';
import departmentRoutes from './department.routes.js';
import stateRoutes from './state.routes.js';
import countryRoutes from './country.routes.js';
import tagRoutes from './tag.routes.js';
import resultRoutes from './result.routes.js';
import examRoutes from './exam.routes.js';
import subjectRoutes from './subject.routes.js';
import topicRoutes from './topic.routes.js';
import topicGroupRoutes from './topicGroup.routes.js';
import searchRoutes from './search.routes.js';
import subscriberRoutes from './subscriber.routes.js';
import mockTestSeriesRoutes from './mockTestSeries.routes.js';
import mockTestRoutes from './mockTest.routes.js';
import mockTestPlanRoutes from './mockTestPlan.routes.js';
import paymentRoutes from './payment.routes.js';
import backupRoutes from './backup.routes.js';
import stickyNoteRoutes from './stickyNote.routes.js';
import sitemapRoutes from './sitemap.routes.js';

import { getPublicAuthorsList } from '../controllers/user.controller.js';

const router = express.Router();

// Base API Route
router.get('/', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Education Masters REST API Service',
    status: 'active',
    version: 'v1',
    timestamp: new Date().toISOString(),
    availableRoutes: {
      auth: '/auth',
      users: '/users',
      blogs: '/blogs',
      jobs: '/jobs',
      admitCards: '/admit-cards',
      results: '/results',
      mcqs: '/mcqs',
      questions: '/questions',
      mockTests: '/mock-tests',
      mockTestSeries: '/mock-test-series',
      mockTestPlans: '/mock-test-plans',
      stickyNotes: '/sticky-notes',
      institutes: '/institutes',
      courses: '/courses',
      facilities: '/facilities',
      categories: '/categories',
      departments: '/departments',
      exams: '/exams',
      subjects: '/subjects',
      topics: '/topics',
      topicGroups: '/topic-groups',
      states: '/states',
      countries: '/countries',
      tags: '/tags',
      media: '/media',
      stats: '/stats',
      search: '/search',
      subscribers: '/subscribers',
      authors: '/authors',
      payments: '/payments',
    },
  });
});

router.use('/sitemap', sitemapRoutes);
router.use('/backup', backupRoutes);
router.use('/sticky-notes', stickyNoteRoutes);
router.use('/sticky-note', stickyNoteRoutes);
router.use('/payments', paymentRoutes);
router.use('/mock-test-series', mockTestSeriesRoutes);
router.use('/mock-tests', mockTestRoutes);
router.use('/mock-test-plans', mockTestPlanRoutes);
router.use('/subscribers', subscriberRoutes);
router.use('/subscriber', subscriberRoutes);
router.get('/authors', getPublicAuthorsList);
router.use('/search', searchRoutes);
router.use('/admit-cards', admitCardRoutes);
router.use('/admit-card', admitCardRoutes);
router.use('/results', resultRoutes);
router.use('/result', resultRoutes);
router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/author', userRoutes);
router.use('/blogs', blogRoutes);
router.use('/jobs', jobRoutes);
router.use('/job', jobRoutes);
router.use('/institutes', instituteRoutes);
router.use('/institute', instituteRoutes);
router.use('/courses', courseRoutes);
router.use('/course', courseRoutes);
router.use('/facilities', facilityRoutes);
router.use('/facility', facilityRoutes);
router.use('/media', mediaRoutes);
router.use('/stats', statsRoutes);
router.use('/mcqs', questionRoutes);
router.use('/questions', questionRoutes);
router.use('/categories', categoryRoutes);
router.use('/departments', departmentRoutes);
router.use('/department', departmentRoutes);
router.use('/countries', countryRoutes);
router.use('/country', countryRoutes);
router.use('/tags', tagRoutes);
router.use('/tag', tagRoutes);
router.use('/states', stateRoutes);
router.use('/districts', stateRoutes);
router.use('/exams', examRoutes);
router.use('/exam', examRoutes);
router.use('/subjects', subjectRoutes);
router.use('/subject', subjectRoutes);
router.use('/topics', topicRoutes);
router.use('/topic', topicRoutes);
router.use('/topic-groups', topicGroupRoutes);
router.use('/topic-group', topicGroupRoutes);

export default router;
