import asyncHandler from '../utils/asyncHandler.js';
import ApiResponse from '../utils/apiResponse.js';
import { Question, Subject, State, Exam, District, Topic, MockTest, MockTestSeries } from '../models/index.js';

// Helper to update total_tests and free_tests on MockTestSeries
async function updateSeriesCounters(seriesId) {
  try {
    const [totalTests, freeTests, allTests] = await Promise.all([
      MockTest.countDocuments({ series: seriesId, status: { $in: ['publish', 'published', 'Published'] } }),
      MockTest.countDocuments({
        series: seriesId,
        $or: [{ is_paid: false }, { is_free: true }],
        status: { $in: ['publish', 'published', 'Published'] },
      }),
      MockTest.find({ series: seriesId }).select('questions').lean(),
    ]);

    const totalQuestions = allTests.reduce((acc, t) => acc + (t.questions?.length || 0), 0);

    await MockTestSeries.findByIdAndUpdate(seriesId, {
      total_tests: totalTests,
      free_tests_count: freeTests,
      total_questions: totalQuestions,
    });
  } catch (err) {
    console.error('Error updating series counters:', err);
  }
}

const validateQuestionData = (data, { isNew = false } = {}) => {
  const errors = {};

  if (isNew || data.content !== undefined) {
    const content = String(data.content || '').trim();
    if (!content) {
      errors.content = 'Question content is required';
    } else if (content.length < 3) {
      errors.content = 'Question content must be at least 3 characters long';
    }
  }

  if (isNew || data.options !== undefined) {
    if (!Array.isArray(data.options) || data.options.length < 2) {
      errors.options = 'At least 2 options are required (e.g. Option 1 and Option 2)';
    } else {
      const validOptions = data.options.filter((opt) => opt && String(opt.text || '').trim().length > 0);
      if (validOptions.length < 2) {
        errors.options = 'Please fill in at least 2 option descriptions';
      }
    }
  }

  if (isNew || data.correct_answer !== undefined || data.options !== undefined) {
    const hasCorrect =
      Boolean(data.correct_answer) ||
      (Array.isArray(data.options) && data.options.some((opt) => opt && opt.is_correct));
    if (!hasCorrect) {
      errors.correct_answer = 'Please select the correct answer option';
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};

export const getQuestions = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page, 10) || 1;
  const limit = parseInt(req.query.limit, 10) || 20;
  const skip = (page - 1) * limit;

  const search = (req.query.search || req.query.q || '').trim();
  const statusFilter = (req.query.status || 'all').toLowerCase();
  const subjectFilter = req.query.subject || '';
  const stateFilter = req.query.state || '';
  const examFilter = req.query.exam || '';
  const levelFilter = req.query.level || '';
  const dateFilter = req.query.date || '';

  // Base query
  const query = {};

  // Status filtering
  if (statusFilter === 'published' || statusFilter === 'publish') {
    query.status = { $in: ['publish', 'published', 'Published'] };
  } else if (statusFilter === 'draft' || statusFilter === 'drafts') {
    query.status = { $in: ['draft', 'Draft'] };
  } else if (statusFilter === 'pending') {
    query.status = { $in: ['pending', 'Pending'] };
  } else if (statusFilter === 'trash' || statusFilter === 'trashed') {
    query.status = { $in: ['trash', 'trashed', 'Trashed'] };
  } else {
    // 'all' tab shows non-trashed questions by default, matching standard CMS/WordPress behavior
    query.status = { $nin: ['trash', 'trashed', 'Trashed'] };
  }

  // Search filter
  if (search) {
    if (!isNaN(search)) {
      query.$or = [
        { sql_id: Number(search) },
        { content: { $regex: search, $options: 'i' } },
        { 'options.text': { $regex: search, $options: 'i' } },
        { subject_name: { $regex: search, $options: 'i' } },
        { state_name: { $regex: search, $options: 'i' } },
        { author_name: { $regex: search, $options: 'i' } },
      ];
    } else {
      query.$or = [
        { content: { $regex: search, $options: 'i' } },
        { 'options.text': { $regex: search, $options: 'i' } },
        { subject_name: { $regex: search, $options: 'i' } },
        { state_name: { $regex: search, $options: 'i' } },
        { author_name: { $regex: search, $options: 'i' } },
      ];
    }
  }

  if (subjectFilter && subjectFilter !== 'all') {
    if (/^[0-9a-fA-F]{24}$/.test(subjectFilter)) {
      query.subject = subjectFilter;
    } else {
      const cleanSub = subjectFilter.replace(/-/g, ' ');
      const subRegex = new RegExp(`^${cleanSub.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i');
      const subjectDoc = await Subject.findOne({
        $or: [
          { slug: subjectFilter.toLowerCase() },
          { name: subRegex },
        ],
      });
      if (subjectDoc) {
        query.$or = [
          { subject: subjectDoc._id },
          { subject_name: { $regex: subjectDoc.name, $options: 'i' } },
          { subject_name: { $regex: cleanSub, $options: 'i' } },
        ];
      } else {
        query.subject_name = { $regex: cleanSub, $options: 'i' };
      }
    }
  }

  if (stateFilter && stateFilter !== 'all') {
    if (/^[0-9a-fA-F]{24}$/.test(stateFilter)) {
      query.state = stateFilter;
    } else {
      const cleanState = stateFilter.replace(/-/g, ' ');
      const stateRegex = new RegExp(`^${cleanState.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i');
      const stateDoc = await State.findOne({
        $or: [
          { slug: stateFilter.toLowerCase() },
          { name: stateRegex },
        ],
      });
      if (stateDoc) {
        query.$or = [
          { state: stateDoc._id },
          { state_name: { $regex: stateDoc.name, $options: 'i' } },
          { state_name: { $regex: cleanState, $options: 'i' } },
        ];
      } else {
        query.state_name = { $regex: cleanState, $options: 'i' };
      }
    }
  }

  if (examFilter && examFilter !== 'all') {
    if (/^[0-9a-fA-F]{24}$/.test(examFilter)) {
      query.examinations = examFilter;
    } else {
      const cleanExam = examFilter.replace(/-/g, ' ');
      query.examination_names = { $in: [new RegExp(cleanExam, 'i'), new RegExp(examFilter, 'i')] };
    }
  }

  const languageFilter = req.query.language || req.query.lang || req.query.medium || '';
  if (languageFilter && languageFilter !== 'all') {
    query.language = { $regex: languageFilter, $options: 'i' };
  }

  const topicFilter = req.query.topic || '';
  if (topicFilter && topicFilter !== 'all') {
    if (/^[0-9a-fA-F]{24}$/.test(topicFilter)) {
      query.topic = topicFilter;
    } else {
      query.topic_name = { $regex: topicFilter.replace(/-/g, ' '), $options: 'i' };
    }
  }

  const mockTestSeriesFilter = req.query.mock_test_series || '';
  if (mockTestSeriesFilter) {
    query.mock_test_series = mockTestSeriesFilter;
  }

  const mockTestFilter = req.query.mock_test || '';
  if (mockTestFilter) {
    query.mock_tests = mockTestFilter;
  }

  if (levelFilter && levelFilter !== 'all') {
    query.$or = [
      { 'level.slug': levelFilter },
      { 'level.name': { $regex: levelFilter, $options: 'i' } },
      { level: { $regex: levelFilter, $options: 'i' } },
    ];
  }

  if (dateFilter) {
    // E.g. YYYY-MM
    query.createdAt = {
      $gte: new Date(`${dateFilter}-01T00:00:00.000Z`),
      $lt: new Date(`${dateFilter}-31T23:59:59.999Z`),
    };
  }

  // Author-specific scoping: If user is an author or writer, only show their own questions
  const userRole = (req.user?.role || '').toLowerCase();
  const userId = req.user?._id || req.user?.id;
  const userSqlId = req.user?.sql_id;
  const authorParam = req.query.author || '';

  const isAuthor = userRole === 'author' || userRole === 'writer' || userRole === 'contributor';

  let authorCondition = null;
  if (isAuthor && userId) {
    const orConds = [{ author: userId }];
    if (userSqlId) orConds.push({ user_id: userSqlId });
    if (req.user?.name) orConds.push({ author_name: req.user.name });
    authorCondition = { $or: orConds };
  } else if (authorParam) {
    const isObjectId = /^[0-9a-fA-F]{24}$/.test(String(authorParam).trim());
    const numId = Number(authorParam);
    const orConds = [];
    if (isObjectId) orConds.push({ author: authorParam });
    if (!isNaN(numId) && numId > 0) orConds.push({ user_id: numId });
    if (orConds.length > 0) authorCondition = { $or: orConds };
  }

  if (authorCondition) {
    if (query.$or) {
      query.$and = [{ $or: query.$or }, authorCondition];
      delete query.$or;
    } else {
      query.$and = [authorCondition];
    }
  }

  const countAuthorFilter = authorCondition ? { ...authorCondition } : {};

  // Get status counts for badges (scoped by author if applicable)
  const [
    allCount,
    publishedCount,
    draftCount,
    pendingCount,
    trashCount,
    questions,
    totalFiltered,
  ] = await Promise.all([
    Question.countDocuments({ ...countAuthorFilter, status: { $nin: ['trash', 'trashed', 'Trashed'] } }),
    Question.countDocuments({ ...countAuthorFilter, status: { $in: ['publish', 'published', 'Published'] } }),
    Question.countDocuments({ ...countAuthorFilter, status: { $in: ['draft', 'Draft'] } }),
    Question.countDocuments({ ...countAuthorFilter, status: { $in: ['pending', 'Pending'] } }),
    Question.countDocuments({ ...countAuthorFilter, status: { $in: ['trash', 'trashed', 'Trashed'] } }),
    Question.find(query)
      .populate('author', 'name email')
      .populate('subject', 'name slug')
      .populate('state', 'name slug')
      .populate('district', 'name slug')
      .populate('examinations', 'name slug')
      .sort({ sql_id: -1, createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .lean(),
    Question.countDocuments(query),
  ]);

  res.status(200).json({
    success: true,
    data: questions,
    counts: {
      all: allCount,
      published: publishedCount,
      draft: draftCount,
      pending: pendingCount,
      trash: trashCount,
    },
    pagination: {
      page,
      limit,
      total: totalFiltered,
      pages: Math.ceil(totalFiltered / limit) || 1,
    },
  });
});

export const getQuestionById = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const isObjectId = /^[0-9a-fA-F]{24}$/.test(id);

  const query = isObjectId ? { _id: id } : { sql_id: Number(id) };

  const question = await Question.findOne(query)
    .populate('author', 'name email')
    .populate('subject', 'name slug')
    .populate('topic', 'name slug')
    .populate('state', 'name slug')
    .populate('district', 'name slug')
    .populate('examinations', 'name slug')
    .populate('mock_test_series', 'title slug image')
    .populate('mock_tests', 'title slug test_type is_paid is_free')
    .lean();

  if (!question) {
    throw new ApiError(404, 'Question not found');
  }

  res.status(200).json(new ApiResponse(200, question, 'Question retrieved successfully'));
});

// Helper to verify if user has authority to modify question
const checkQuestionOwnership = (question, user) => {
  if (!user) return false;
  const userRole = (user.role || '').toLowerCase();
  if (userRole === 'admin' || userRole === 'superadmin' || userRole === 'editor') {
    return true;
  }
  const userId = user._id || user.id;
  if (question.author && String(question.author) === String(userId)) return true;
  if (user.sql_id && question.user_id === user.sql_id) return true;
  if (user.name && question.author_name === user.name) return true;
  return false;
};

export const createQuestion = asyncHandler(async (req, res) => {
  const validation = validateQuestionData(req.body, { isNew: true });
  if (!validation.isValid) {
    return res.status(400).json({
      success: false,
      message: Object.values(validation.errors)[0] || 'Validation failed. Please fix the highlighted fields.',
      errors: validation.errors,
    });
  }

  const {
    content,
    instruction,
    ans_info,
    marks,
    negative,
    type,
    language,
    level,
    subject,
    subject_name,
    topic,
    topic_name,
    mock_test_series,
    mock_tests,
    state,
    state_name,
    district,
    district_name,
    city,
    examinations,
    examination_names,
    options,
    correct_answer,
    status,
  } = req.body;

  // Resolve subject name if ID is provided
  let resolvedSubjectName = subject_name || '';
  let resolvedSubjectId = subject || null;
  if (subject && /^[0-9a-fA-F]{24}$/.test(subject)) {
    const sDoc = await Subject.findById(subject).lean();
    if (sDoc) resolvedSubjectName = sDoc.name;
  }

  // Resolve topic name if ID is provided
  let resolvedTopicName = topic_name || '';
  let resolvedTopicId = topic || null;
  if (topic && /^[0-9a-fA-F]{24}$/.test(topic)) {
    const tDoc = await Topic.findById(topic).lean();
    if (tDoc) resolvedTopicName = tDoc.name;
  }

  // Resolve state name if ID is provided
  let resolvedStateName = state_name || '';
  let resolvedStateId = state || null;
  if (state && /^[0-9a-fA-F]{24}$/.test(state)) {
    const stDoc = await State.findById(state).lean();
    if (stDoc) resolvedStateName = stDoc.name;
  }

  // Resolve examinations
  let resolvedExamNames = Array.isArray(examination_names) ? [...examination_names] : [];
  let resolvedExamIds = Array.isArray(examinations) ? examinations.filter((e) => /^[0-9a-fA-F]{24}$/.test(e)) : [];
  if (resolvedExamIds.length > 0 && resolvedExamNames.length === 0) {
    const examDocs = await Exam.find({ _id: { $in: resolvedExamIds } }).select('name').lean();
    resolvedExamNames = examDocs.map((e) => e.name);
  }

  // Resolve mock_test_series & mock_tests
  let resolvedMockTestSeries = Array.isArray(mock_test_series)
    ? mock_test_series.filter((s) => /^[0-9a-fA-F]{24}$/.test(s))
    : (mock_test_series && /^[0-9a-fA-F]{24}$/.test(mock_test_series) ? [mock_test_series] : []);

  let resolvedMockTests = Array.isArray(mock_tests)
    ? mock_tests.filter((t) => /^[0-9a-fA-F]{24}$/.test(t))
    : (mock_tests && /^[0-9a-fA-F]{24}$/.test(mock_tests) ? [mock_tests] : []);

  // Formatted options
  const formattedOptions = (options || []).map((opt, idx) => {
    const optText = typeof opt === 'string' ? opt : (opt.text || '');
    const isCorrect = typeof opt === 'object' ? Boolean(opt.is_correct) : false;
    return {
      index: idx + 1,
      text: optText.trim(),
      is_correct: isCorrect,
    };
  });

  // Calculate correct_answer text/index if option is marked
  let resolvedCorrect = correct_answer || '';
  if (!resolvedCorrect) {
    const correctOpt = formattedOptions.find((o) => o.is_correct);
    if (correctOpt) {
      resolvedCorrect = String.fromCharCode(65 + (correctOpt.index - 1)); // 'A', 'B', etc.
    }
  } else {
    // If correct_answer provided (e.g. 'A' or '1' or exact text), ensure matching option has is_correct = true
    const letterIdx = resolvedCorrect.length === 1 && /[A-Fa-f]/.test(resolvedCorrect)
      ? resolvedCorrect.toUpperCase().charCodeAt(0) - 65
      : -1;
    formattedOptions.forEach((opt, idx) => {
      if (idx === letterIdx || opt.text.trim() === resolvedCorrect.trim()) {
        opt.is_correct = true;
      }
    });
  }

  const highest = await Question.findOne({ sql_id: { $ne: null } }).sort({ sql_id: -1 }).select('sql_id').lean();
  const nextSqlId = (highest?.sql_id || 0) + 1;

  const authorId = req.user?._id || req.user?.id || null;
  const authorName = req.user?.name || req.user?.nicename || 'Author';
  const authorSqlId = req.user?.sql_id || null;

  const newQuestion = await Question.create({
    sql_id: nextSqlId,
    content: content.trim(),
    instruction: instruction || '',
    ans_info: ans_info || '',
    marks: Number(marks) || 1,
    negative: Number(negative) || 0,
    type: type || { name: 'Objective', slug: 'objective' },
    language: language || 'Hindi',
    level: level || { name: 'Medium', slug: 'medium' },
    subject: resolvedSubjectId,
    subject_name: resolvedSubjectName,
    topic: resolvedTopicId,
    topic_name: resolvedTopicName,
    mock_test_series: resolvedMockTestSeries,
    mock_tests: resolvedMockTests,
    state: resolvedStateId,
    state_name: resolvedStateName,
    district: district || null,
    district_name: district_name || '',
    city: city || '',
    examinations: resolvedExamIds,
    examination_names: resolvedExamNames,
    options: formattedOptions,
    correct_answer: resolvedCorrect,
    author: authorId,
    author_name: authorName,
    user_id: authorSqlId,
    status: status || 'Published',
  });

  // If allocated to mock tests, add question ID to those tests and update counters
  if (resolvedMockTests.length > 0) {
    for (const testId of resolvedMockTests) {
      await MockTest.findByIdAndUpdate(testId, {
        $addToSet: { questions: newQuestion._id },
      });
      const tDoc = await MockTest.findById(testId).select('questions series').lean();
      if (tDoc) {
        await MockTest.findByIdAndUpdate(testId, { total_questions: tDoc.questions?.length || 0 });
        if (tDoc.series) await updateSeriesCounters(tDoc.series);
      }
    }
  }

  res.status(201).json(new ApiResponse(201, newQuestion, 'Question created successfully'));
});

export const updateQuestion = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const question = await Question.findById(id);
  if (!question) {
    throw new ApiError(404, 'Question not found');
  }

  if (!checkQuestionOwnership(question, req.user)) {
    throw new ApiError(403, 'Permission denied: You can only edit your own MCQs.');
  }

  const validation = validateQuestionData(req.body, { isNew: false });
  if (!validation.isValid) {
    return res.status(400).json({
      success: false,
      message: Object.values(validation.errors)[0] || 'Validation failed. Please fix the highlighted fields.',
      errors: validation.errors,
    });
  }

  const {
    content,
    instruction,
    ans_info,
    marks,
    negative,
    type,
    language,
    level,
    subject,
    topic,
    topic_name,
    mock_test_series,
    mock_tests,
    state,
    district,
    city,
    examinations,
    options,
    correct_answer,
    status,
  } = req.body;

  if (content !== undefined) question.content = content.trim();
  if (instruction !== undefined) question.instruction = instruction;
  if (ans_info !== undefined) question.ans_info = ans_info;
  if (marks !== undefined) question.marks = Number(marks) || 1;
  if (negative !== undefined) question.negative = Number(negative) || 0;
  if (type !== undefined) question.type = type;
  if (language !== undefined) question.language = language;
  if (level !== undefined) question.level = level;
  if (city !== undefined) question.city = city;
  if (status !== undefined) question.status = status;

  if (subject !== undefined) {
    if (subject && /^[0-9a-fA-F]{24}$/.test(subject)) {
      const sDoc = await Subject.findById(subject).lean();
      question.subject = sDoc ? sDoc._id : null;
      question.subject_name = sDoc ? sDoc.name : '';
    } else {
      question.subject = null;
      question.subject_name = '';
    }
  }

  if (topic !== undefined) {
    if (topic && /^[0-9a-fA-F]{24}$/.test(topic)) {
      const tDoc = await Topic.findById(topic).lean();
      question.topic = tDoc ? tDoc._id : null;
      question.topic_name = tDoc ? tDoc.name : '';
    } else {
      question.topic = null;
      question.topic_name = topic_name || '';
    }
  }

  if (mock_test_series !== undefined) {
    const validSeries = Array.isArray(mock_test_series)
      ? mock_test_series.filter((s) => /^[0-9a-fA-F]{24}$/.test(s))
      : (mock_test_series && /^[0-9a-fA-F]{24}$/.test(mock_test_series) ? [mock_test_series] : []);
    question.mock_test_series = validSeries;
  }

  if (mock_tests !== undefined) {
    const prevTests = (question.mock_tests || []).map(String);
    const newTests = Array.isArray(mock_tests)
      ? mock_tests.filter((t) => /^[0-9a-fA-F]{24}$/.test(t)).map(String)
      : (mock_tests && /^[0-9a-fA-F]{24}$/.test(mock_tests) ? [String(mock_tests)] : []);

    question.mock_tests = newTests;

    // Tests to remove question from
    const removedTests = prevTests.filter((tId) => !newTests.includes(tId));
    for (const testId of removedTests) {
      await MockTest.findByIdAndUpdate(testId, {
        $pull: { questions: question._id },
      });
      const tDoc = await MockTest.findById(testId).select('questions series').lean();
      if (tDoc) {
        await MockTest.findByIdAndUpdate(testId, { total_questions: tDoc.questions?.length || 0 });
        if (tDoc.series) await updateSeriesCounters(tDoc.series);
      }
    }

    // Tests to add question to
    const addedTests = newTests.filter((tId) => !prevTests.includes(tId));
    for (const testId of addedTests) {
      await MockTest.findByIdAndUpdate(testId, {
        $addToSet: { questions: question._id },
      });
      const tDoc = await MockTest.findById(testId).select('questions series').lean();
      if (tDoc) {
        await MockTest.findByIdAndUpdate(testId, { total_questions: tDoc.questions?.length || 0 });
        if (tDoc.series) await updateSeriesCounters(tDoc.series);
      }
    }
  }

  if (state !== undefined) {
    if (state && /^[0-9a-fA-F]{24}$/.test(state)) {
      const stDoc = await State.findById(state).lean();
      question.state = stDoc ? stDoc._id : null;
      question.state_name = stDoc ? stDoc.name : '';
    } else {
      question.state = null;
      question.state_name = '';
    }
  }

  if (district !== undefined) {
    question.district = district || null;
  }

  if (examinations !== undefined) {
    const validIds = Array.isArray(examinations) ? examinations.filter((e) => /^[0-9a-fA-F]{24}$/.test(e)) : [];
    question.examinations = validIds;
    if (validIds.length > 0) {
      const examDocs = await Exam.find({ _id: { $in: validIds } }).select('name').lean();
      question.examination_names = examDocs.map((e) => e.name);
    } else {
      question.examination_names = [];
    }
  }

  if (options !== undefined) {
    const formattedOptions = (options || []).map((opt, idx) => {
      const optText = typeof opt === 'string' ? opt : (opt.text || '');
      const isCorrect = typeof opt === 'object' ? Boolean(opt.is_correct) : false;
      return {
        index: idx + 1,
        text: optText.trim(),
        is_correct: isCorrect,
      };
    });

    let resolvedCorrect = correct_answer !== undefined ? correct_answer : question.correct_answer;
    if (!resolvedCorrect) {
      const correctOpt = formattedOptions.find((o) => o.is_correct);
      if (correctOpt) {
        resolvedCorrect = String.fromCharCode(65 + (correctOpt.index - 1));
      }
    } else {
      const letterIdx = resolvedCorrect.length === 1 && /[A-Fa-f]/.test(resolvedCorrect)
        ? resolvedCorrect.toUpperCase().charCodeAt(0) - 65
        : -1;
      formattedOptions.forEach((opt, idx) => {
        if (idx === letterIdx || opt.text.trim() === String(resolvedCorrect).trim()) {
          opt.is_correct = true;
        }
      });
    }

    question.options = formattedOptions;
    question.correct_answer = resolvedCorrect;
  }

  question.editor = req.user?._id || req.user?.id || null;
  await question.save();

  res.status(200).json(new ApiResponse(200, question, 'Question updated successfully'));
});

export const deleteQuestion = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const force = req.query.force === 'true' || req.query.force === true;

  const question = await Question.findById(id);
  if (!question) {
    throw new ApiError(404, 'Question not found');
  }

  if (!checkQuestionOwnership(question, req.user)) {
    throw new ApiError(403, 'Permission denied: You can only delete your own MCQs.');
  }

  if (force || question.status === 'trashed' || question.status === 'trash' || question.status === 'Trashed') {
    await Question.findByIdAndDelete(id);
    return res.status(200).json(new ApiResponse(200, null, 'Question permanently deleted'));
  }

  question.status = 'trashed';
  question.deleted_at = new Date();
  await question.save();

  res.status(200).json(new ApiResponse(200, question, 'Question moved to trash'));
});

export const restoreQuestion = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const question = await Question.findById(id);
  if (!question) {
    throw new ApiError(404, 'Question not found');
  }

  if (!checkQuestionOwnership(question, req.user)) {
    throw new ApiError(403, 'Permission denied: You can only restore your own MCQs.');
  }

  question.status = 'Published';
  question.deleted_at = null;
  await question.save();

  res.status(200).json(new ApiResponse(200, question, 'Question restored successfully'));
});

export const bulkActionQuestions = asyncHandler(async (req, res) => {
  const { action, ids } = req.body;
  if (!Array.isArray(ids) || ids.length === 0) {
    throw new ApiError(400, 'No questions selected');
  }

  const userRole = (req.user?.role || '').toLowerCase();
  const userId = req.user?._id || req.user?.id;
  const isAuthor = userRole === 'author' || userRole === 'writer' || userRole === 'contributor';

  let targetQuery = { _id: { $in: ids } };
  if (isAuthor && userId) {
    const orConds = [{ author: userId }];
    if (req.user?.sql_id) orConds.push({ user_id: req.user.sql_id });
    if (req.user?.name) orConds.push({ author_name: req.user.name });
    targetQuery = { _id: { $in: ids }, $or: orConds };
  }

  if (action === 'publish' || action === 'Published') {
    await Question.updateMany(targetQuery, { $set: { status: 'Published', deleted_at: null } });
    return res.status(200).json(new ApiResponse(200, null, `Published questions`));
  }

  if (action === 'draft' || action === 'Draft') {
    await Question.updateMany(targetQuery, { $set: { status: 'Draft', deleted_at: null } });
    return res.status(200).json(new ApiResponse(200, null, `Moved questions to Draft`));
  }

  if (action === 'trash' || action === 'trashed') {
    await Question.updateMany(targetQuery, { $set: { status: 'trashed', deleted_at: new Date() } });
    return res.status(200).json(new ApiResponse(200, null, `Moved questions to Trash`));
  }

  if (action === 'restore') {
    await Question.updateMany(targetQuery, { $set: { status: 'Published', deleted_at: null } });
    return res.status(200).json(new ApiResponse(200, null, `Restored questions`));
  }

  if (action === 'delete' || action === 'force_delete') {
    await Question.deleteMany(targetQuery);
    return res.status(200).json(new ApiResponse(200, null, `Permanently deleted questions`));
  }

  throw new ApiError(400, 'Invalid bulk action');
});

export const importExcelQuestions = asyncHandler(async (req, res) => {
  const { questions: items, batchDefaults = {} } = req.body;

  if (!Array.isArray(items) || items.length === 0) {
    throw new ApiError(400, 'No questions provided for import');
  }

  const [subjects, states, districts, exams, topics] = await Promise.all([
    Subject.find({}).lean(),
    State.find({}).lean(),
    District.find({}).lean(),
    Exam.find({}).lean(),
    Topic.find({}).lean(),
  ]);

  const highest = await Question.findOne({ sql_id: { $ne: null } }).sort({ sql_id: -1 }).select('sql_id').lean();
  let nextSqlId = (highest?.sql_id || 0) + 1;

  const authorId = req.user?._id || req.user?.id || null;
  const authorName = req.user?.name || req.user?.nicename || 'Excel Importer';
  const authorSqlId = req.user?.sql_id || null;

  // Resolve Batch Defaults if provided
  let batchDefaultState = null;
  if (batchDefaults.state) {
    batchDefaultState = states.find(
      (s) => String(s._id) === String(batchDefaults.state) || s.name.toLowerCase() === String(batchDefaults.state).toLowerCase()
    );
  }

  let batchDefaultDistrict = null;
  if (batchDefaults.district) {
    batchDefaultDistrict = districts.find(
      (d) => String(d._id) === String(batchDefaults.district) || d.name.toLowerCase() === String(batchDefaults.district).toLowerCase()
    );
  }

  let batchDefaultSubject = null;
  if (batchDefaults.subject) {
    batchDefaultSubject = subjects.find(
      (s) => String(s._id) === String(batchDefaults.subject) || s.name.toLowerCase() === String(batchDefaults.subject).toLowerCase()
    );
  }

  let batchDefaultTopic = null;
  if (batchDefaults.topic) {
    batchDefaultTopic = topics.find(
      (t) => String(t._id) === String(batchDefaults.topic) || t.name.toLowerCase() === String(batchDefaults.topic).toLowerCase()
    );
  }

  let batchDefaultExamIds = [];
  let batchDefaultExamNames = [];
  if (Array.isArray(batchDefaults.examinations) && batchDefaults.examinations.length > 0) {
    batchDefaults.examinations.forEach((ex) => {
      const match = exams.find((e) => String(e._id) === String(ex) || e.name.toLowerCase() === String(ex).toLowerCase());
      if (match && !batchDefaultExamIds.some((id) => String(id) === String(match._id))) {
        batchDefaultExamIds.push(match._id);
        batchDefaultExamNames.push(match.name);
      }
    });
  } else if (batchDefaults.examination || batchDefaults.exam) {
    const raw = String(batchDefaults.examination || batchDefaults.exam);
    const match = exams.find((e) => String(e._id) === raw || e.name.toLowerCase() === raw.toLowerCase());
    if (match) {
      batchDefaultExamIds.push(match._id);
      batchDefaultExamNames.push(match.name);
    }
  }

  // Resolve Batch Defaults for Mock Tests
  let batchDefaultMockTestSeriesIds = [];
  if (Array.isArray(batchDefaults.mock_test_series)) {
    batchDefaultMockTestSeriesIds = batchDefaults.mock_test_series.filter((id) => /^[0-9a-fA-F]{24}$/.test(id));
  } else if (batchDefaults.mock_test_series && /^[0-9a-fA-F]{24}$/.test(batchDefaults.mock_test_series)) {
    batchDefaultMockTestSeriesIds = [batchDefaults.mock_test_series];
  }

  let batchDefaultMockTestIds = [];
  if (Array.isArray(batchDefaults.mock_tests)) {
    batchDefaultMockTestIds = batchDefaults.mock_tests.filter((id) => /^[0-9a-fA-F]{24}$/.test(id));
  } else if (batchDefaults.mock_tests && /^[0-9a-fA-F]{24}$/.test(batchDefaults.mock_tests)) {
    batchDefaultMockTestIds = [batchDefaults.mock_tests];
  } else if (batchDefaults.mock_test && /^[0-9a-fA-F]{24}$/.test(batchDefaults.mock_test)) {
    batchDefaultMockTestIds = [batchDefaults.mock_test];
  }

  const validDocs = [];
  const errors = [];

  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    const rowNum = i + 2; // Excel row reference (header is row 1)

    const content = String(item.content || item.question || item.Question || item['Question Text'] || '').trim();
    if (!content) {
      errors.push({ row: rowNum, error: 'Question text is missing' });
      continue;
    }

    // Extract options
    const optA = String(item.option_a || item.option1 || item.OptionA || item.Option1 || item['Option A'] || item['Option 1'] || item.A || '').trim();
    const optB = String(item.option_b || item.option2 || item.OptionB || item.Option2 || item['Option B'] || item['Option 2'] || item.B || '').trim();
    const optC = String(item.option_c || item.option3 || item.OptionC || item.Option3 || item['Option C'] || item['Option 3'] || item.C || '').trim();
    const optD = String(item.option_d || item.option4 || item.OptionD || item.Option4 || item['Option D'] || item['Option 4'] || item.D || '').trim();
    const optE = String(item.option_e || item.option5 || item.OptionE || item.Option5 || item['Option E'] || item['Option 5'] || item.E || '').trim();
    const optF = String(item.option_f || item.option6 || item.OptionF || item.Option6 || item['Option F'] || item['Option 6'] || item.F || '').trim();

    const options = [];
    if (optA) options.push({ index: 1, text: optA, is_correct: false });
    if (optB) options.push({ index: 2, text: optB, is_correct: false });
    if (optC) options.push({ index: 3, text: optC, is_correct: false });
    if (optD) options.push({ index: 4, text: optD, is_correct: false });
    if (optE) options.push({ index: 5, text: optE, is_correct: false });
    if (optF) options.push({ index: 6, text: optF, is_correct: false });

    if (options.length < 2) {
      errors.push({ row: rowNum, error: `At least 2 options required, found ${options.length}` });
      continue;
    }

    // Resolve correct answer
    const rawAnswer = String(item.answer || item.correct_answer || item.Answer || item.CorrectAnswer || item['Correct Answer'] || '').trim();
    let isCorrectMatched = false;

    if (rawAnswer) {
      const upperAns = rawAnswer.toUpperCase();
      if (['A', 'B', 'C', 'D', 'E', 'F'].includes(upperAns)) {
        const targetIdx = upperAns.charCodeAt(0) - 65;
        if (options[targetIdx]) {
          options[targetIdx].is_correct = true;
          isCorrectMatched = true;
        }
      } else if (['1', '2', '3', '4', '5', '6'].includes(rawAnswer)) {
        const targetIdx = Number(rawAnswer) - 1;
        if (options[targetIdx]) {
          options[targetIdx].is_correct = true;
          isCorrectMatched = true;
        }
      } else {
        // Search matching option text
        const matched = options.find((o) => o.text.toLowerCase() === rawAnswer.toLowerCase());
        if (matched) {
          matched.is_correct = true;
          isCorrectMatched = true;
        }
      }
    }

    if (!isCorrectMatched && options.length > 0) {
      options[0].is_correct = true; // Fallback to Option A
    }

    // Resolve subject
    const rawSubject = String(item.subject || item.Subject || '').trim();
    let matchedSubject = batchDefaultSubject;
    if (rawSubject) {
      const found = subjects.find(
        (s) => s.name.toLowerCase() === rawSubject.toLowerCase() || s.slug.toLowerCase() === rawSubject.toLowerCase()
      );
      if (found) matchedSubject = found;
    }

    // Resolve topic
    const rawTopic = String(item.topic || item.Topic || '').trim();
    let matchedTopic = batchDefaultTopic;
    if (rawTopic) {
      const found = topics.find(
        (t) => t.name.toLowerCase() === rawTopic.toLowerCase() || t.slug.toLowerCase() === rawTopic.toLowerCase()
      );
      if (found) matchedTopic = found;
    }

    // Resolve state
    const rawState = String(item.state || item.State || '').trim();
    let matchedState = batchDefaultState;
    if (rawState) {
      const found = states.find(
        (s) => s.name.toLowerCase() === rawState.toLowerCase() || s.slug.toLowerCase() === rawState.toLowerCase()
      );
      if (found) matchedState = found;
    }

    // Resolve district
    const rawDistrict = String(item.district || item.District || '').trim();
    let matchedDistrict = batchDefaultDistrict;
    if (rawDistrict) {
      const found = districts.find(
        (d) => d.name.toLowerCase() === rawDistrict.toLowerCase()
      );
      if (found) matchedDistrict = found;
    }

    // Resolve city
    const rawCity = String(item.city || item.City || item.location || item.Location || '').trim();
    const finalCity = rawCity || batchDefaults.city || '';

    // Resolve exam
    const rawExam = String(item.exam || item.examination || item.Exam || item.Examinations || item.examinations || '').trim();
    let matchedExamIds = [...batchDefaultExamIds];
    let matchedExamNames = [...batchDefaultExamNames];

    if (rawExam) {
      const examParts = rawExam.split(/[,;|]/).map((p) => p.trim()).filter(Boolean);
      for (const part of examParts) {
        const foundExam = exams.find(
          (e) => e.name.toLowerCase() === part.toLowerCase() || e.slug.toLowerCase() === part.toLowerCase()
        );
        if (foundExam && !matchedExamIds.some((id) => String(id) === String(foundExam._id))) {
          matchedExamIds.push(foundExam._id);
          matchedExamNames.push(foundExam.name);
        }
      }
    }

    // Mock test series and mock tests
    const rowMockSeries = String(item.mock_test_series || item['Mock Test Series'] || item.test_series || '').trim();
    const rowMockTest = String(item.mock_test || item['Mock Test'] || item.test || '').trim();

    let matchedMockSeriesIds = [...batchDefaultMockTestSeriesIds];
    let matchedMockTestIds = [...batchDefaultMockTestIds];

    if (rowMockSeries && /^[0-9a-fA-F]{24}$/.test(rowMockSeries)) {
      if (!matchedMockSeriesIds.includes(rowMockSeries)) matchedMockSeriesIds.push(rowMockSeries);
    }
    if (rowMockTest && /^[0-9a-fA-F]{24}$/.test(rowMockTest)) {
      if (!matchedMockTestIds.includes(rowMockTest)) matchedMockTestIds.push(rowMockTest);
    }

    // Language
    const rawLanguage = String(item.language || item.Language || batchDefaults.language || 'Hindi').trim();

    // Level
    const rawLevel = String(item.level || item.Level || item.difficulty || item.Difficulty || batchDefaults.level || 'Medium').trim();

    // Status
    const rawStatus = String(item.status || item.Status || batchDefaults.status || 'Published').trim();

    const doc = {
      sql_id: nextSqlId++,
      content,
      instruction: String(item.instruction || item.Instruction || '').trim(),
      ans_info: String(item.ans_info || item.explanation || item.Explanation || item.solution || item.Solution || '').trim(),
      marks: Number(item.marks || item.Marks) || Number(batchDefaults.marks) || 1,
      negative: Number(item.negative || item.Negative || item['Negative Marks']) || Number(batchDefaults.negative) || 0,
      type: { name: 'Objective', slug: 'objective' },
      language: rawLanguage,
      level: {
        name: rawLevel,
        slug: rawLevel.toLowerCase(),
      },
      subject: matchedSubject ? matchedSubject._id : null,
      subject_name: matchedSubject ? matchedSubject.name : (rawSubject || batchDefaults.subject_name || ''),
      topic: matchedTopic ? matchedTopic._id : null,
      topic_name: matchedTopic ? matchedTopic.name : (rawTopic || batchDefaults.topic_name || ''),
      mock_test_series: matchedMockSeriesIds,
      mock_tests: matchedMockTestIds,
      state: matchedState ? matchedState._id : null,
      state_name: matchedState ? matchedState.name : (rawState || batchDefaults.state_name || ''),
      district: matchedDistrict ? matchedDistrict._id : null,
      district_name: matchedDistrict ? matchedDistrict.name : (rawDistrict || batchDefaults.district_name || ''),
      city: finalCity,
      examinations: matchedExamIds,
      examination_names: matchedExamNames,
      options,
      correct_answer: rawAnswer || 'A',
      author: authorId,
      author_name: authorName,
      user_id: authorSqlId,
      status: rawStatus,
    };

    validDocs.push(doc);
  }

  let insertedCount = 0;
  if (validDocs.length > 0) {
    const inserted = await Question.insertMany(validDocs, { ordered: false });
    insertedCount = inserted.length;

    // Allocate newly inserted questions to tests
    const testToQuestionsMap = new Map();
    for (const doc of inserted) {
      if (Array.isArray(doc.mock_tests) && doc.mock_tests.length > 0) {
        for (const tId of doc.mock_tests) {
          const strId = String(tId);
          if (!testToQuestionsMap.has(strId)) {
            testToQuestionsMap.set(strId, []);
          }
          testToQuestionsMap.get(strId).push(doc._id);
        }
      }
    }

    // Update each MockTest
    for (const [tId, qIds] of testToQuestionsMap.entries()) {
      await MockTest.findByIdAndUpdate(tId, {
        $addToSet: { questions: { $each: qIds } },
      });
      const tDoc = await MockTest.findById(tId).select('questions series').lean();
      if (tDoc) {
        await MockTest.findByIdAndUpdate(tId, { total_questions: tDoc.questions?.length || 0 });
        if (tDoc.series) await updateSeriesCounters(tDoc.series);
      }
    }
  }

  res.status(200).json({
    success: true,
    message: `Successfully imported ${insertedCount} questions (${errors.length} skipped with errors).`,
    imported: insertedCount,
    skipped: errors.length,
    errors,
  });
});
