import NextAuth from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import GoogleProvider from 'next-auth/providers/google';
import { decode as defaultDecode } from 'next-auth/jwt';

const BACKEND_URL =
  process.env.INTERNAL_BACKEND_URL ||
  process.env.BACKEND_URL ||
  process.env.NEXT_PUBLIC_BACKEND_URL ||
  (process.env.NODE_ENV === 'production'
    ? 'https://education-masters-cv8z.vercel.app'
    : 'http://localhost:5001');
const NEXTAUTH_SECRET = process.env.NEXTAUTH_SECRET || 'educationmasters_nextauth_secret_2026_super_secure_key';

const getTodayDateString = (dateObj = new Date()) => {
  const d = new Date(dateObj);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export const authOptions = {
  trustHost: true,
  providers: [
    ...(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET
      ? [
        GoogleProvider({
          clientId: process.env.GOOGLE_CLIENT_ID,
          clientSecret: process.env.GOOGLE_CLIENT_SECRET,
        }),
      ]
      : []),
    CredentialsProvider({
      name: 'Credentials',
      credentials: {
        email: { label: 'Email', type: 'text' },
        password: { label: 'Password', type: 'password' },
        authType: { label: 'AuthType', type: 'text' },
        userId: { label: 'UserId', type: 'text' },
        otp: { label: 'OTP', type: 'text' },
        phone: { label: 'Phone', type: 'text' },
        rawToken: { label: 'RawToken', type: 'text' },
      },
      async authorize(credentials) {
        // Mode 1: OTP Verification sign-in
        if (credentials?.authType === 'otp-verify') {
          if (!credentials.otp || (!credentials.userId && !credentials.phone && !credentials.email)) {
            throw new Error('Please enter OTP and phone or user identifier');
          }

          try {
            const res = await fetch(`${BACKEND_URL}/apis/v1/auth/verify-otp`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                userId: credentials.userId,
                otp: credentials.otp,
                phone: credentials.phone,
                email: credentials.email,
              }),
            });

            const data = await res.json();
            if (res.ok && data.success && data.data?.token) {
              return {
                id: data.data.user.id,
                name: data.data.user.name,
                nicename: data.data.user.nicename,
                email: data.data.user.email,
                role: data.data.user.role,
                permissions: data.data.user.permissions || [],
                institute_id: data.data.user.institute_id || null,
                login_time: data.data.user.login_time || null,
                logout_time: data.data.user.logout_time || null,
                last_login_time: data.data.user.last_login_time || null,
                session_date: data.data.user.session_date || null,
                expires_at: data.data.user.expires_at || null,
                accessToken: data.data.token,
              };
            } else {
              throw new Error(data.message || 'OTP verification failed');
            }
          } catch (error) {
            throw new Error(error.message || 'OTP authentication failed');
          }
        }

        // Mode 2: Direct session token injection (e.g. from Google login or direct token)
        if (credentials?.authType === 'session-token' && credentials?.rawToken) {
          try {
            const res = await fetch(`${BACKEND_URL}/apis/v1/auth/me`, {
              method: 'GET',
              headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${credentials.rawToken}`,
              },
            });
            const data = await res.json();
            if (res.ok && data.success && data.data?.user) {
              return {
                id: data.data.user.id,
                name: data.data.user.name,
                nicename: data.data.user.nicename,
                email: data.data.user.email,
                role: data.data.user.role,
                permissions: data.data.user.permissions || [],
                institute_id: data.data.user.institute_id || null,
                login_time: data.data.user.login_time || null,
                logout_time: data.data.user.logout_time || null,
                last_login_time: data.data.user.last_login_time || null,
                session_date: data.data.user.session_date || null,
                expires_at: data.data.user.expires_at || null,
                accessToken: credentials.rawToken,
              };
            } else {
              throw new Error(data.message || 'Session token invalid or expired');
            }
          } catch (error) {
            throw new Error(error.message || 'Token session failed');
          }
        }

        // Mode 3: Standard Email + Password
        if (!credentials?.email || !credentials?.password) {
          throw new Error('Please enter your email and password');
        }

        try {
          const res = await fetch(`${BACKEND_URL}/apis/v1/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              email: credentials.email,
              password: credentials.password,
            }),
          });

          const data = await res.json();

          if (res.ok && data.success && data.data?.token) {
            return {
              id: data.data.user.id,
              name: data.data.user.name,
              nicename: data.data.user.nicename,
              email: data.data.user.email,
              role: data.data.user.role,
              permissions: data.data.user.permissions || [],
              institute_id: data.data.user.institute_id || null,
              login_time: data.data.user.login_time || null,
              logout_time: data.data.user.logout_time || null,
              last_login_time: data.data.user.last_login_time || null,
              session_date: data.data.user.session_date || null,
              expires_at: data.data.user.expires_at || null,
              accessToken: data.data.token,
            };
          } else {
            throw new Error(data.message || 'Invalid email or password');
          }
        } catch (error) {
          throw new Error(error.message || 'Authentication failed');
        }
      },
    }),
  ],
  jwt: {
    async decode(params) {
      try {
        return await defaultDecode(params);
      } catch {

        return null;
      }
    },
  },
  callbacks: {
    async jwt({ token, user, trigger, session }) {
      if (user) {
        token.id = user.id;
        token.name = user.name;
        token.nicename = user.nicename;
        token.role = user.role;
        token.permissions = user.permissions;
        token.institute_id = user.institute_id;
        token.login_time = user.login_time;
        token.logout_time = user.logout_time;
        token.last_login_time = user.last_login_time;
        token.session_date = user.session_date;
        token.expires_at = user.expires_at;
        token.accessToken = user.accessToken;
      }
      if (trigger === 'update' && session) {
        if (session.logout_time) token.logout_time = session.logout_time;
        if (session.login_time) token.login_time = session.login_time;
      }

      // Check if session has expired past 12:00 AM midnight or on next calendar day
      const now = new Date();
      const todayStr = getTodayDateString(now);

      const isDateExpired = Boolean(token?.session_date && token.session_date !== todayStr);
      const isTimeExpired = Boolean(token?.expires_at && now.getTime() >= new Date(token.expires_at).getTime());

      if (isDateExpired || isTimeExpired) {
        token.isExpired = true;
      }

      return token;
    },
    async session({ session, token }) {
      if (!token || token.isExpired) {
        return null;
      }

      if (token) {
        session.user.id = token.id;
        session.user.name = token.name;
        session.user.nicename = token.nicename;
        session.user.role = token.role;
        session.user.permissions = token.permissions;
        session.user.institute_id = token.institute_id;
        session.user.login_time = token.login_time;
        session.user.logout_time = token.logout_time;
        session.user.last_login_time = token.last_login_time;
        session.user.session_date = token.session_date;
        session.user.expires_at = token.expires_at;
        session.user.accessToken = token.accessToken;
      }
      return session;
    },
  },

  pages: {
    signIn: '/edu-login',
  },
  session: {
    strategy: 'jwt',
    maxAge: 24 * 60 * 60,
  },
  secret: NEXTAUTH_SECRET,
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };
