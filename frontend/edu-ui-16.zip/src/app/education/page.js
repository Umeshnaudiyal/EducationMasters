import { redirect } from 'next/navigation';

export default function EducationRedirect() {
  redirect('/category/education');
}
