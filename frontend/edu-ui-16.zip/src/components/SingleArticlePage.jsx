'use client';

import React, { useState, useEffect } from 'react';
import { useParams, usePathname, notFound } from 'next/navigation';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import LiveTicker from '@/components/LiveTicker';
import {
  Calendar, User, Share2, Copy, Bookmark,
  ExternalLink, Download, ChevronRight, ChevronDown, X,
  Send, MessageSquare, Check, Award, Globe,
  Building, Clock, FileText, HelpCircle, CheckCircle2,
  Share, BookmarkCheck, Mail, Phone
} from 'lucide-react';
import StateLink, { isPlaceholderString } from '@/components/StateLink';
import InternalLinkModal, { isInternalLink } from '@/components/InternalLinkModal';
import { getImageUrl } from '@/utils/image';
import authorsData from '@/utils/authorsData.json';
import { API_BASE } from '@/utils/api';

const findAuthorInCatalog = (identifier) => {
  if (!identifier) return null;
  const cleanId = String(identifier).trim().toLowerCase();
  return (
    authorsData.find((a) => {
      if (!a) return false;
      const aId = (a._id || '').toLowerCase();
      const aSlug = (a.slug || '').toLowerCase();
      const aNice = (a.nicename || '').toLowerCase();
      const aName = (a.name || '').toLowerCase();
      const aEmail = (a.email || '').toLowerCase();
      return (
        aId === cleanId ||
        aSlug === cleanId ||
        aNice === cleanId ||
        aName === cleanId ||
        aEmail === cleanId
      );
    }) || null
  );
};

const formatSocialUrl = (type, val) => {
  if (!val || typeof val !== 'string') return '';
  const clean = val.trim();
  if (!clean) return '';
  if (clean.startsWith('http://') || clean.startsWith('https://')) return clean;

  switch (type) {
    case 'twitter':
      return `https://twitter.com/${clean.replace(/^@/, '')}`;
    case 'facebook':
      return `https://facebook.com/${clean}`;
    case 'instagram':
      return `https://instagram.com/${clean.replace(/^@/, '')}`;
    case 'linkedin':
      return clean.startsWith('in/') ? `https://linkedin.com/${clean}` : `https://linkedin.com/in/${clean}`;
    case 'youtube':
      return `https://youtube.com/${clean.startsWith('@') ? clean : `@${clean}`}`;
    case 'website':
      return `https://${clean}`;
    default:
      return clean;
  }
};



// Helper for clean, bulletproof date formatting
const formatDate = (dateStr) => {
  if (!dateStr || dateStr === '0000-00-00') return 'As per scheduled';
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return String(dateStr);
    return d.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
  } catch (e) {
    return String(dateStr);
  }
};

// Robust HTML & text sanitizer helper (removes SQL migration artifacts like 'rn', decodes entities)
const cleanHTML = (contentStr) => {
  if (!contentStr) return '';
  let str = String(contentStr);

  str = str
    .replace(/\\r\\n/g, ' ')
    .replace(/\\n/g, ' ')
    .replace(/\\r/g, ' ')
    .replace(/\brn\b/g, ' ')
    .replace(/rn</g, '<')
    .replace(/>rn/g, '>')
    .replace(/&ndash;/g, '–')
    .replace(/&mdash;/g, '—')
    .replace(/&amp;/g, '&')
    .replace(/&nbsp;/g, ' ')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");

  return str.trim();
};

// Helper to normalize and fix external URLs
const formatExternalUrl = (urlStr) => {
  if (!urlStr || typeof urlStr !== 'string') return '';
  let url = urlStr.trim().replace(/,/g, '.');
  if (!url || url === 'null' || url === 'undefined') return '';
  if (url.startsWith('http://') || url.startsWith('https://')) return url;
  return `https://${url}`;
};

// Parse structured FAQ questions & answers from HTML string or raw content
const parseFaqs = (faqRaw, defaultExamName = '') => {
  if (!faqRaw) return [];
  if (Array.isArray(faqRaw)) return faqRaw;

  const cleaned = cleanHTML(faqRaw);
  if (!cleaned) return [];

  // Match pattern like <li><strong>Q?</strong></li> <p>Answer</p> or <p><strong>Q. Question?</strong></p><p>Answer</p>
  const faqs = [];
  const regex = /<(?:li|p|h[3-6]|div)[^>]*>\s*<strong[^>]*>([^<]+)<\/strong>\s*<\/(?:li|p|h[3-6]|div)>\s*<(?:p|div)[^>]*>(.*?)<\/(?:p|div)>/gi;
  let match;

  while ((match = regex.exec(cleaned)) !== null) {
    let q = match[1].replace(/^[Q0-9.\s]+/, '').trim();
    let a = match[2].replace(/^Answer:\s*/i, '').replace(/<[^>]*>/g, '').trim();
    if (q && a) {
      faqs.push({ question: q, answer: a });
    }
  }

  // If regex parsing didn't find pairs, check if list items exist
  if (faqs.length === 0) {
    const listItems = cleaned.match(/<li[^>]*>(.*?)<\/li>/gi);
    if (listItems && listItems.length > 0) {
      listItems.forEach((item, idx) => {
        const text = item.replace(/<[^>]*>/g, '').trim();
        if (text) {
          faqs.push({
            question: `Question ${idx + 1}`,
            answer: text
          });
        }
      });
    }
  }

  return faqs;
};

// Helper to parse HTML instructions (inst_down or inst_impl) into clean text items
const parseInstructionItems = (htmlStr) => {
  if (!htmlStr) return [];
  const cleaned = cleanHTML(htmlStr);
  const items = [];

  const liMatches = cleaned.match(/<li[^>]*>(.*?)<\/li>/gi);
  if (liMatches && liMatches.length > 0) {
    liMatches.forEach((li) => {
      const text = li.replace(/<[^>]*>/g, '').trim();
      if (text) items.push(text);
    });
  } else {
    // Split by paragraphs or newlines
    const pMatches = cleaned.match(/<p[^>]*>(.*?)<\/p>/gi);
    if (pMatches && pMatches.length > 0) {
      pMatches.forEach((p) => {
        const text = p.replace(/<[^>]*>/g, '').trim();
        if (text) items.push(text);
      });
    } else {
      const lines = cleaned.split(/\n+/).map(l => l.replace(/<[^>]*>/g, '').trim()).filter(Boolean);
      items.push(...lines);
    }
  }

  return items;
};



const formatArticleData = (rawInput, type = '', currentPathname = '') => {
  if (!rawInput) return null;
  // Unwrap if payload is wrapped in { data: {...}, type: '...' }
  const raw = (rawInput && typeof rawInput === 'object' && rawInput.data && typeof rawInput.data === 'object' && !rawInput.title && !rawInput.post)
    ? rawInput.data
    : rawInput;
  const inferredType = type || (rawInput && rawInput.type) || (raw && raw.type) || '';
  const path = currentPathname || (typeof window !== 'undefined' ? window.location.pathname : '');
  const isResult = inferredType === 'result' || path.startsWith('/result') || raw.result_status !== undefined || (raw.inst_down !== undefined && raw.down_url && !raw.vacancies);
  const isAdmitCard = inferredType === 'admit-card' || path.startsWith('/admit-card');
  const isJob = inferredType === 'job' || path.startsWith('/job') || (!isResult && !isAdmitCard && (raw.vacancies || raw.qualification || raw.posts || raw.app_ends || raw.total_posts));

  let firstCat = raw.categories?.[0] || raw.category;
  let catName = typeof firstCat === 'object' ? (firstCat?.name || firstCat?.slug || '') : String(firstCat || '');
  let catSlug = typeof firstCat === 'object' ? (firstCat?.slug || '') : '';
  if (catName === '[object Object]') catName = '';

  // Extract Department / Board / Agency Name
  const extractDepartment = (rawItem) => {
    if (rawItem.dept && String(rawItem.dept).trim() && !isPlaceholderString(rawItem.dept)) {
      return cleanHTML(rawItem.dept);
    }
    if (rawItem.department) {
      const deptStr = typeof rawItem.department === 'object' ? rawItem.department.name : String(rawItem.department);
      if (deptStr && deptStr.trim() && deptStr !== '[object Object]' && !isPlaceholderString(deptStr)) return cleanHTML(deptStr);
    }
    if (rawItem.board) {
      const boardStr = typeof rawItem.board === 'object' ? rawItem.board.name : String(rawItem.board);
      if (boardStr && boardStr.trim() && boardStr !== '[object Object]' && !isPlaceholderString(boardStr)) return cleanHTML(boardStr);
    }

    const titleStr = (rawItem.title || '').trim();
    const lowerTitle = titleStr.toLowerCase();

    if (lowerTitle.includes('upsc')) return 'UPSC';
    if (lowerTitle.includes('ssc')) return 'SSC';
    if (lowerTitle.includes('aiims')) return 'AIIMS';
    if (lowerTitle.includes('csir')) return 'CSIR';
    if (lowerTitle.includes('iim')) return 'IIM';
    if (lowerTitle.includes('rrb') || lowerTitle.includes('railway')) return 'Railway / RRB';
    if (lowerTitle.includes('tiss')) return 'TISS';
    if (lowerTitle.includes('union bank')) return 'Union Bank';
    if (lowerTitle.includes('bank of baroda') || lowerTitle.includes('bob')) return 'Bank of Baroda';
    if (lowerTitle.includes('sikkim') || lowerTitle.includes('spsc')) return 'SPSC / Sikkim';
    if (lowerTitle.includes('ibps')) return 'IBPS';
    if (lowerTitle.includes('dgqa') || lowerTitle.includes('dgaqa')) return 'DGQA';

    if (catName && typeof catName === 'string' && catName.trim() && !['jobs', 'job', 'articles', 'results', 'admit card', 'uncategorized'].includes(catName.trim().toLowerCase())) {
      return cleanHTML(catName);
    }

    if (isResult) return 'Results';
    if (isAdmitCard) return 'Admit Card';
    if (isJob) return 'Jobs';
    return 'Articles';
  };

  const categoryName = extractDepartment(raw);
  const categorySlug = catSlug || (isResult ? 'results' : isAdmitCard ? 'admit-cards' : isJob ? 'jobs' : 'articles');

  // Extract authentic Author details with rich social profiles and catalogue fallback
  let authorName = 'Vikash Sharma';
  let authorSlug = 'DigitalDeepak';
  let authorImage = 'https://educationmasters.in/assets/img/users/admin_1777271474.png';
  let authorBio = 'Vikash Sharma is an education expert and digital learning strategist with over 10 years of experience in the Indian education ecosystem. As the founder of EducationMasters.in, he is dedicated to helping students and job aspirants stay updated with the latest government exams, results, and career guidance.';
  let authorRole = 'Author';
  let authorNicename = '';
  let authorWebsite = '';
  let authorTwitter = '';
  let authorFacebook = '';
  let authorInstagram = '';
  let authorLinkedin = '';
  let authorYoutube = '';
  let authorEmail = '';
  let authorPhone = '';

  const authorParam = raw.author;
  let catalogMatch = null;

  if (authorParam) {
    if (typeof authorParam === 'object') {
      const rawId = authorParam._id || authorParam.id || '';
      const rawName = (authorParam.name || '').trim();
      const rawNice = (authorParam.nicename || '').trim();
      const rawSlug = (authorParam.slug || '').trim();
      const rawEmail = (authorParam.email || '').trim();

      catalogMatch =
        findAuthorInCatalog(rawId) ||
        findAuthorInCatalog(rawSlug) ||
        findAuthorInCatalog(rawNice) ||
        findAuthorInCatalog(rawName) ||
        findAuthorInCatalog(rawEmail);

      authorSlug = rawNice || rawSlug || rawName || catalogMatch?.slug || catalogMatch?.nicename || 'DigitalDeepak';

      if (rawName.toLowerCase() === 'admin' && rawNice) {
        authorName = rawNice;
      } else if (rawName.length <= 3 && rawNice && rawNice.length > rawName.length) {
        authorName = rawNice;
      } else if (rawName) {
        authorName = rawName;
      } else if (rawNice) {
        authorName = rawNice;
      } else if (catalogMatch?.name) {
        authorName = catalogMatch.name;
      }

      if (authorParam.image) {
        authorImage = getImageUrl(authorParam.image, 'https://educationmasters.in/assets/img/defaults/user.png');
      } else if (catalogMatch?.image) {
        authorImage = getImageUrl(catalogMatch.image, 'https://educationmasters.in/assets/img/defaults/user.png');
      }

      if (authorParam.bio && authorParam.bio.trim()) {
        authorBio = cleanHTML(authorParam.bio);
      } else if (catalogMatch?.bio && catalogMatch.bio.trim()) {
        authorBio = cleanHTML(catalogMatch.bio);
      } else {
        authorBio = `I am ${authorName}, a student and Content Writer at Education Masters, passionate about creating informative, SEO-friendly, and student-focused educational content. I specialize in writing about government jobs, entrance exams, admissions, results, and career guidance to help students make informed academic decisions.`;
      }

      authorRole = authorParam.role || catalogMatch?.role || 'Author';
      authorNicename = rawNice || catalogMatch?.nicename || '';
      authorWebsite = authorParam.website || catalogMatch?.website || '';
      authorTwitter = authorParam.twitter || catalogMatch?.twitter || '';
      authorFacebook = authorParam.facebook || catalogMatch?.facebook || '';
      authorInstagram = authorParam.instagram || catalogMatch?.instagram || '';
      authorLinkedin = authorParam.linkedin || catalogMatch?.linkedin || '';
      authorYoutube = authorParam.youtube || catalogMatch?.youtube || '';
      authorEmail = authorParam.email || catalogMatch?.email || '';
      authorPhone = authorParam.phone || catalogMatch?.phone || '';
    } else if (typeof authorParam === 'string') {
      catalogMatch = findAuthorInCatalog(authorParam);
      if (catalogMatch) {
        authorName = catalogMatch.name || authorParam;
        authorSlug = catalogMatch.slug || catalogMatch.nicename || authorParam;
        authorImage = getImageUrl(catalogMatch.image, 'https://educationmasters.in/assets/img/defaults/user.png');
        authorBio = catalogMatch.bio ? cleanHTML(catalogMatch.bio) : `I am ${authorName}, a student and Content Writer at Education Masters, passionate about creating informative, SEO-friendly, and student-focused educational content.`;
        authorRole = catalogMatch.role || 'Author';
        authorNicename = catalogMatch.nicename || '';
        authorWebsite = catalogMatch.website || '';
        authorTwitter = catalogMatch.twitter || '';
        authorFacebook = catalogMatch.facebook || '';
        authorInstagram = catalogMatch.instagram || '';
        authorLinkedin = catalogMatch.linkedin || '';
        authorYoutube = catalogMatch.youtube || '';
        authorEmail = catalogMatch.email || '';
        authorPhone = catalogMatch.phone || '';
      } else {
        authorName = authorParam;
        authorSlug = authorParam;
      }
    }
  }

  const authorObj = {
    name: authorName,
    slug: authorSlug,
    image: authorImage,
    bio: authorBio,
    role: authorRole,
    nicename: authorNicename,
    website: authorWebsite,
    twitter: authorTwitter,
    facebook: authorFacebook,
    instagram: authorInstagram,
    linkedin: authorLinkedin,
    youtube: authorYoutube,
    email: authorEmail,
    phone: authorPhone,
  };

  const pubDate = formatDate(raw.created_at || raw.createdAt || raw.exam_rdate || raw.result_date);

  // Dynamic Result / Admit Card Details Object
  const examNameVal = cleanHTML(raw.post || raw.title || 'Government Examination 2026');
  const rawDeptCandidate = raw.dept || (typeof raw.department === 'object' ? raw.department?.name : raw.department);
  const deptNameVal = cleanHTML((rawDeptCandidate && !isPlaceholderString(rawDeptCandidate)) ? rawDeptCandidate : (categoryName || 'Official Authority'));
  const postNameVal = cleanHTML(raw.desig || raw.post || raw.title || 'Various Posts');
  const examDateVal = raw.exam_date ? formatDate(raw.exam_date) : (raw.dates?.exam_date ? formatDate(raw.dates.exam_date) : 'As per scheduled');
  const examTimeVal = cleanHTML(raw.exam_time || 'As per scheduled');
  const examModeVal = cleanHTML(raw.exam_mode || 'Offline (OMR Based)');
  const officialWebVal = formatExternalUrl(raw.site_url || raw.website || raw.official_website || (raw.links?.site_url) || (raw.links?.official_website));
  const downUrlVal = formatExternalUrl(raw.down_url || raw.result_url || raw.links?.down_url || raw.links?.result_url || raw.site_url);

  const descriptionHtml = cleanHTML(raw.description || raw.content || '');
  const instDownRaw = cleanHTML(raw.inst_down || raw.downloadInstructions || '');
  const instImplRaw = cleanHTML(raw.inst_impl || raw.importantInstructions || '');
  const faqRaw = cleanHTML(raw.faq_content || raw.faqs || '');

  const parsedInstDown = parseInstructionItems(instDownRaw);
  const parsedInstImpl = parseInstructionItems(instImplRaw);
  const parsedFaqItems = parseFaqs(faqRaw, examNameVal);

  const resultDetailsObj = (isResult || isAdmitCard) ? {
    examName: examNameVal,
    deptName: deptNameVal,
    postName: postNameVal,
    examDate: examDateVal,
    examTime: examTimeVal,
    examMode: examModeVal,
    officialWebsite: officialWebVal,
    downUrl: downUrlVal,
    resultStatus: cleanHTML(raw.result_status || 'Declared / Out'),
    description: descriptionHtml,
    instDown: instDownRaw,
    instDownItems: parsedInstDown,
    instImpl: instImplRaw,
    instImplItems: parsedInstImpl,
    faqContent: faqRaw,
    faqItems: parsedFaqItems
  } : null;

  // Standard Job Details Object
  const rawLocationCandidate = raw.job_location || raw.location || (typeof raw.state === 'object' ? raw.state?.name : raw.state);
  const cleanJobLocation = (rawLocationCandidate && !isPlaceholderString(rawLocationCandidate)) ? cleanHTML(rawLocationCandidate) : 'All India';

  const jobDetailsObj = isJob ? {
    postName: cleanHTML(raw.title),
    totalVacancies: cleanHTML(raw.posts || raw.total_posts || raw.vacancies || 'N/A'),
    jobLocation: cleanJobLocation,
    qualification: cleanHTML(raw.qualification || 'As per notification'),
    releaseDate: formatDate(raw.released || raw.created_at || raw.createdAt),
    startDate: formatDate(raw.app_start || raw.dates?.start_date || raw.created_at),
    endDate: formatDate(raw.app_ends || raw.dates?.last_date),
    examDate: raw.exam_date ? formatDate(raw.exam_date) : 'N/A',
    minAge: raw.min_age ? `${raw.min_age} Years` : 'N/A',
    maxAge: raw.max_age ? `${raw.max_age} Years` : 'N/A',
    salary: cleanHTML(raw.salary || 'As per rules'),
    applicationFee: cleanHTML(raw.fees?.gen_fee ? `General/OBC: ₹${raw.fees.gen_fee} | SC/ST: Exempted` : (raw.fees || 'As per rules')),
    officialLink: formatExternalUrl(raw.noti_link || raw.links?.site_url || raw.site_url),
    applyLink: formatExternalUrl(raw.app_link || raw.links?.down_url || raw.down_url),
    admitCardLink: formatExternalUrl(raw.admitCardNotification?.down_url || raw.links?.admit_url),
    resultLink: formatExternalUrl(raw.resultNotification?.down_url || raw.links?.result_url)
  } : null;

  const metadataObj = raw.metadata ? {
    m_title: cleanHTML(raw.metadata.m_title || raw.title),
    m_desc: cleanHTML(raw.metadata.m_desc || raw.subtitle || ''),
    m_keys: cleanHTML(raw.metadata.m_keys || ''),
    canonical: raw.metadata.canonical || '',
    robots: raw.metadata.robots || 1,
    schema: raw.metadata.schema || ''
  } : null;

  return {
    title: cleanHTML(raw.title || 'Notification Details'),
    subtitle: cleanHTML(raw.subtitle || ''),
    author: authorObj,
    category: categoryName,
    categorySlug: categorySlug,
    date: pubDate,
    lastDate: isJob ? formatDate(raw.app_ends || raw.dates?.last_date) : (isResult ? 'Result Declared' : 'Download Available'),
    image: getImageUrl(raw.featured_media || raw.featured_image || raw.image || raw.banner_image, 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=1200&q=80'),
    content: descriptionHtml,
    state: raw.state,
    dept: deptNameVal,
    isJob,
    isResult,
    isAdmitCard,
    jobDetails: jobDetailsObj,
    resultDetails: resultDetailsObj,
    metadata: metadataObj
  };
};

const generateFallbackArticle = (articleSlug, currentPathname = '') => {
  const formattedTitle = cleanHTML(articleSlug
    .split('-')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' '));

  const isResult = (currentPathname || '').startsWith('/result') || articleSlug.includes('result');

  if (isResult) {
    return {
      title: `${formattedTitle} Result 2026 - Check Merit List & Selection Status`,
      subtitle: '',
      author: {
        name: 'adityapanwarjaat',
        image: 'https://educationmasters.in/assets/img/defaults/user.png',
        bio: 'I am Aditya, a student and Content Writer at Education Masters, passionate about creating informative, SEO-friendly, and student-focused educational content. I specialize in writing about government jobs, entrance exams, admissions, results, and career guidance to help students make informed academic decisions.'
      },
      category: 'Result',
      categorySlug: 'results',
      date: 'Sep 21, 2026',
      lastDate: 'Result Declared',
      image: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=1200&q=80',
      isResult: true,
      resultDetails: {
        examName: formattedTitle,
        deptName: 'Examination Authority',
        postName: 'Manager, Specialist Officer & Various Posts',
        examDate: 'As per scheduled',
        examTime: 'As per scheduled',
        examMode: 'Offline (OMR Based)',
        officialWebsite: 'https://educationmasters.in',
        downUrl: 'https://educationmasters.in',
        resultStatus: 'Declared / Out',
        description: `<p>The <strong>${formattedTitle} Result 2026</strong> has been announced for candidates who appeared in the examination process. Candidates can check their qualifying status, score card, and merit list through the official portal.</p><p>The result will show the qualifying status of candidates and details about the next stage of selection. Depending on the post, candidates may be shortlisted through Online Examination, Group Discussion or Personal Interview.</p>`,
        instDownItems: [
          'Visit the official recruitment website.',
          'Open the Careers / Recruitment / Result section.',
          `Find "${formattedTitle} Result 2026".`,
          'Click on the result or shortlisted candidates link when released.',
          'Enter your Registration Number and Password/Date of Birth, if login is required.',
          'Submit the details.',
          'Check your result and qualifying status.',
          'Download and save the result PDF or scorecard for future reference.'
        ],
        instImplItems: [
          'Check your name, roll number and qualifying status carefully.',
          'Download a copy of the result for future use.',
          'Check the next selection stage mentioned in the result.',
          'Keep your original documents ready for Document Verification.',
          'Regularly check the official recruitment page for further updates.'
        ],
        faqItems: [
          { question: `When will ${formattedTitle} Result 2026 be released?`, answer: 'The result date has been announced on the official website. Candidates can check their status using the direct link provided above.' },
          { question: `How can I download ${formattedTitle} Result 2026?`, answer: 'Visit the official website, open the result section, enter your login credentials and download your scorecard PDF.' },
          { question: `What happens after the ${formattedTitle} Result 2026?`, answer: 'Qualified candidates will move to the next selection stage applicable to their post, such as Document Verification or Interview.' }
        ]
      }
    };
  }

  return {
    title: 'UPSC Recruitment 2026 for 212 Specialist, Assistant Professor and More Posts',
    subtitle: '',
    author: {
      name: 'Mohit',
      image: 'https://educationmasters.in/assets/img/defaults/user.png',
      bio: 'I am mohit, a student and Content Writer at Education Masters, passionate about creating informative, SEO-friendly, and student-focused educational content. I specialize in writing about government jobs, entrance exams, admissions, results, and career guidance to help students make informed academic and career decisions.'
    },
    category: 'UPSC',
    categorySlug: 'jobs',
    date: 'Sep 13, 2026',
    image: 'https://images.unsplash.com/photo-1541829070764-84a7d30dd3f3?auto=format&fit=crop&w=1200&q=80',
    isJob: true,
    jobDetails: {
      postName: 'UPSC Recruitment 2026 for 212 Specialist, Assistant Professor and More Posts',
      totalVacancies: '212 Vacancies',
      qualification: 'Master Degree, MBBS, MD/MS, B.E/B.Tech or equivalent',
      ageLimit: '18 to 40 Years',
      salary: 'Pay Level 7 to Level 11 + Applicable Allowances',
      applicationFee: 'General/OBC: ₹25 | SC/ST/Female: Exempted',
      endDate: 'October 02, 2026',
      officialLink: 'https://upsc.gov.in',
      applyLink: 'https://upsconline.nic.in'
    },
    content: `<p>The <strong>UPSC Recruitment 2026 for 212 Specialist, Assistant Professor and More Posts</strong> has been announced by the Union Public Service Commission.</p>`
  };
};

export default function SingleArticlePage({ initialData = null }) {
  const params = useParams();
  const pathname = usePathname() || '';
  const slug = params?.slug || '';

  const [article, setArticle] = useState(() => (initialData ? formatArticleData(initialData, initialData.type || '', typeof window !== 'undefined' ? window.location.pathname : '') : null));
  const [expiringJobs, setExpiringJobs] = useState([]);
  const [relatedJobs, setRelatedJobs] = useState([]);
  const [expiringCount, setExpiringCount] = useState(0);
  const [sidebarLoading, setSidebarLoading] = useState(true);
  const [sidebarTab, setSidebarTab] = useState('expiring'); // 'expiring' or 'mcq'
  const [loading, setLoading] = useState(() => !initialData);
  const [isBannerLoaded, setIsBannerLoaded] = useState(false);
  const [showLeftAd, setShowLeftAd] = useState(true);
  const [copiedLink, setCopiedLink] = useState(false);
  const [internalLinkModal, setInternalLinkModal] = useState({
    isOpen: false,
    targetUrl: '',
    targetWindow: '_self',
  });

  // Reset banner loaded status when article image changes
  useEffect(() => {
    setIsBannerLoaded(false);
  }, [article?.image]);

  const handleArticleContentClick = (e) => {
    const link = e.target.closest('a');
    if (!link) return;

    const href = link.getAttribute('href');
    if (!href || href === '#' || href.startsWith('javascript:') || href.startsWith('mailto:') || href.startsWith('tel:')) {
      return;
    }

    // Never intercept channel join links, share buttons, top breadcrumbs, or byline author
    if (
      link.closest('nav') ||
      link.closest('.share-buttons') ||
      link.closest('[data-no-interception]') ||
      link.getAttribute('data-no-interception') ||
      href.includes('whatsapp.com/channel') ||
      href.includes('t.me/educationmastersin') ||
      href.includes('api.whatsapp.com/send') ||
      href.includes('facebook.com/educationmastersindia')
    ) {
      return;
    }

    // Check if clicked inside text editor raw HTML, highlights table, overview table, or article body
    const isInsideArticleContent = Boolean(
      link.closest('.article-raw-html') ||
      link.closest('.article-content-body') ||
      link.closest('table') ||
      link.closest('.overflow-x-auto')
    );

    if (isInsideArticleContent) {
      e.preventDefault();
      e.stopPropagation();
      setInternalLinkModal({
        isOpen: true,
        targetUrl: href,
        targetWindow: link.getAttribute('target') || '_blank',
      });
    }
  };

  const isJobPage = pathname.startsWith('/job') || article?.isJob;
  const isAdmitCardPage = pathname.startsWith('/admit-card') || article?.isAdmitCard || article?.category?.toLowerCase().includes('admit');
  const isResultPage = pathname.startsWith('/result') || article?.isResult || article?.category?.toLowerCase().includes('result');

  useEffect(() => {
    window.scrollTo(0, 0);
    if (initialData) {
      const formatted = formatArticleData(initialData, initialData.type || '', pathname);
      setArticle(formatted);
      setLoading(false);
      fetchSidebarJobs();
      fetchRelatedJobs();
    } else if (slug) {
      fetchArticleData(slug);
    } else {
      setLoading(false);
    }
  }, [slug, pathname, initialData]);

  // Dynamically update page Title, Meta Description & Keywords
  useEffect(() => {
    if (article && typeof document !== 'undefined') {
      const rawTitle = article.title || article.metadata?.m_title;
      if (rawTitle) {
        document.title = `${rawTitle} | Education Masters`;
      }
      if (article.metadata?.m_desc) {
        let metaDesc = document.querySelector('meta[name="description"]');
        if (!metaDesc) {
          metaDesc = document.createElement('meta');
          metaDesc.name = 'description';
          document.head.appendChild(metaDesc);
        }
        metaDesc.content = article.metadata.m_desc;
      }
      if (article.metadata?.m_keys) {
        let metaKeys = document.querySelector('meta[name="keywords"]');
        if (!metaKeys) {
          metaKeys = document.createElement('meta');
          metaKeys.name = 'keywords';
          document.head.appendChild(metaKeys);
        }
        metaKeys.content = article.metadata.m_keys;
      }
    }
  }, [article]);

  const fetchArticleData = async (articleSlug) => {
    setLoading(true);
    try {
      fetchSidebarJobs();
      fetchRelatedJobs();

      // 1. If on /result route, try Result endpoint first
      if (pathname.startsWith('/result')) {
        const resRes = await fetch(`${API_BASE}/results/${articleSlug}`);
        const dataRes = await resRes.json();
        if (dataRes.success && dataRes.data) {
          setArticle(formatArticleData(dataRes.data, 'result'));
          setLoading(false);
          return;
        }
      }

      // 2. If on /admit-card route, try Admit Card endpoint first
      if (pathname.startsWith('/admit-card')) {
        const resAC = await fetch(`${API_BASE}/admit-cards/${articleSlug}`);
        const dataAC = await resAC.json();
        if (dataAC.success && dataAC.data) {
          setArticle(formatArticleData(dataAC.data, 'admit-card'));
          setLoading(false);
          return;
        }
      }

      // 3. If on /job route, try Job endpoint first
      if (pathname.startsWith('/job')) {
        const resJob = await fetch(`${API_BASE}/jobs/${articleSlug}`);
        const dataJob = await resJob.json();
        if (dataJob.success && dataJob.data) {
          setArticle(formatArticleData(dataJob.data, 'job'));
          setLoading(false);
          return;
        }
      }

      // 4. Try Blog endpoint
      let res = await fetch(`${API_BASE}/blogs/${articleSlug}`);
      let data = await res.json();

      if (data.success && data.data) {
        setArticle(formatArticleData(data.data, 'blog'));
        setLoading(false);
        return;
      }

      // 5. Fallback check results
      if (!pathname.startsWith('/result')) {
        res = await fetch(`${API_BASE}/results/${articleSlug}`);
        data = await res.json();
        if (data.success && data.data) {
          setArticle(formatArticleData(data.data, 'result'));
          setLoading(false);
          return;
        }
      }

      // 6. Fallback check admit cards
      if (!pathname.startsWith('/admit-card')) {
        res = await fetch(`${API_BASE}/admit-cards/${articleSlug}`);
        data = await res.json();
        if (data.success && data.data) {
          setArticle(formatArticleData(data.data, 'admit-card'));
          setLoading(false);
          return;
        }
      }

      // 7. Fallback check jobs
      if (!pathname.startsWith('/job')) {
        res = await fetch(`${API_BASE}/jobs/${articleSlug}`);
        data = await res.json();
        if (data.success && data.data) {
          setArticle(formatArticleData(data.data, 'job'));
          setLoading(false);
          return;
        }
      }

      // If not found in any endpoint, trigger notFound
      notFound();
    } catch (err) {
      console.error('Fetch article error:', err);
      notFound();
    } finally {
      setLoading(false);
    }
  };

  const fetchSidebarJobs = async () => {
    try {
      setSidebarLoading(true);
      const res = await fetch(`${API_BASE}/jobs/expiring-soon?limit=6`);
      const data = await res.json();
      if (data.success && Array.isArray(data.data) && data.data.length > 0) {
        const formatted = data.data.map((item, idx) => ({
          id: item._id || idx,
          title: cleanHTML(item.title),
          slug: item.slug || `job-${idx}`,
          lastDate: formatDate(item.app_ends || item.dates?.last_date),
          category: 'Jobs',
          image: getImageUrl(item.featured_media, '/logo.webp')
        }));
        setExpiringJobs(formatted);
        setExpiringCount(data.total || data.count || formatted.length);
      } else {
        // When no jobs are expiring in the next 30 days, load real published jobs from database
        const fallbackRes = await fetch(`${API_BASE}/jobs?status=publish&limit=6`);
        const fallbackData = await fallbackRes.json();
        if (fallbackData.success && Array.isArray(fallbackData.data) && fallbackData.data.length > 0) {
          const formatted = fallbackData.data.map((item, idx) => ({
            id: item._id || idx,
            title: cleanHTML(item.title),
            slug: item.slug || `job-${idx}`,
            lastDate: formatDate(item.app_ends || item.dates?.last_date),
            category: 'Jobs',
            image: getImageUrl(item.featured_media, '/logo.webp')
          }));
          setExpiringJobs(formatted);
          setExpiringCount(0); // 0 indicates showing latest jobs
        } else {
          setExpiringJobs([]);
          setExpiringCount(0);
        }
      }
    } catch (err) {
      console.error('Sidebar fetch error:', err);
      try {
        const fallbackRes = await fetch(`${API_BASE}/jobs?status=publish&limit=6`);
        const fallbackData = await fallbackRes.json();
        if (fallbackData.success && Array.isArray(fallbackData.data) && fallbackData.data.length > 0) {
          const formatted = fallbackData.data.map((item, idx) => ({
            id: item._id || idx,
            title: cleanHTML(item.title),
            slug: item.slug || `job-${idx}`,
            lastDate: formatDate(item.app_ends || item.dates?.last_date),
            category: 'Jobs',
            image: getImageUrl(item.featured_media, '/logo.webp')
          }));
          setExpiringJobs(formatted);
          setExpiringCount(0);
        } else {
          setExpiringJobs([]);
        }
      } catch (fbErr) {
        setExpiringJobs([]);
      }
    } finally {
      setSidebarLoading(false);
    }
  };

  const fetchRelatedJobs = async () => {
    try {
      const res = await fetch(`${API_BASE}/jobs?status=publish&limit=6`);
      const data = await res.json();
      if (data.success && Array.isArray(data.data) && data.data.length > 0) {
        const formatted = data.data.map((item, idx) => ({
          id: item._id || idx,
          title: cleanHTML(item.title),
          slug: item.slug || `job-${idx}`,
          lastDate: formatDate(item.app_ends || item.dates?.last_date),
          category: 'Jobs',
          image: getImageUrl(item.featured_media, '/logo.webp')
        }));
        setRelatedJobs(formatted);
      } else {
        setRelatedJobs([]);
      }
    } catch (err) {
      console.error('Related jobs fetch error:', err);
      setRelatedJobs([]);
    }
  };

  const handleCopyLink = () => {
    if (typeof window !== 'undefined') {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const currentUrl = typeof window !== 'undefined' ? window.location.href : 'https://educationmasters.in';

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-800 font-sans">
      {/* Global CSS overrides for clean HTML rendering */}
      <style jsx global>{`
        .article-raw-html {
          width: 100% !important;
          max-width: 100% !important;
          word-break: break-word;
          overflow-wrap: break-word;
        }
        .article-raw-html table {
          width: 100% !important;
          display: block !important;
          overflow-x: auto !important;
          max-width: 100% !important;
          border-collapse: collapse !important;
          margin-top: 1rem !important;
          margin-bottom: 1.5rem !important;
          border: 1px solid #e2e8f0 !important;
        }
        .article-raw-html th {
          background-color: #f8fafc !important;
          font-weight: 600 !important;
          color: #334155 !important;
          padding: 0.75rem !important;
          border: 1px solid #e2e8f0 !important;
          text-align: left !important;
        }
        .article-raw-html td {
          padding: 0.75rem !important;
          border: 1px solid #e2e8f0 !important;
          color: #1e293b !important;
          font-weight: 400 !important;
        }
        .article-raw-html ul {
          list-style-type: disc !important;
          padding-left: 1.25rem !important;
          margin-top: 0.5rem !important;
          margin-bottom: 1rem !important;
        }
        .article-raw-html ol {
          list-style-type: decimal !important;
          padding-left: 1.25rem !important;
          margin-top: 0.5rem !important;
          margin-bottom: 1rem !important;
        }
        .article-raw-html li {
          margin-bottom: 0.35rem !important;
          line-height: 1.6 !important;
        }
        .article-raw-html a {
          color: #2563eb !important;
          text-decoration: underline !important;
          font-weight: 500 !important;
        }
        .article-raw-html h2, .article-raw-html h3 {
          font-weight: 700 !important;
          color: #0f172a !important;
          margin-top: 1.75rem !important;
          margin-bottom: 0.75rem !important;
        }
        .article-raw-html p {
          width: 100% !important;
          max-width: 100% !important;
          margin-bottom: 0.85rem !important;
          line-height: 1.7 !important;
          color: #334155 !important;
          text-align: justify !important;
          text-justify: inter-word !important;
          hyphens: auto;
          -webkit-hyphens: auto;
        }
        @media (min-width: 640px) {
          .article-raw-html p {
            text-align: left !important;
          }
        }
        .article-raw-html div,
        .article-raw-html span {
          max-width: 100% !important;
        }
        .article-raw-html img {
          max-width: 100% !important;
          height: auto !important;
          display: block !important;
          margin: 1.25rem auto !important;
          border-radius: 0.5rem !important;
          background-color: #f1f5f9;
          min-height: 140px;
        }
      `}</style>

      <Header />
      <LiveTicker />

      {/* Main Page Container */}
      <main className="flex-1 w-full max-w-[1440px] mx-auto px-3 sm:px-6 py-4 md:py-6">

        {/* 3-Column Layout Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

          {/* ================= LEFT SKYSCRAPER AD CONTAINER ================= */}
          {showLeftAd && (
            <aside className="hidden xl:block xl:col-span-2 sticky top-20 self-start z-10">
              <div className="w-[160px] mx-auto bg-slate-900 text-white rounded overflow-hidden shadow-sm relative group">
                <button
                  onClick={() => setShowLeftAd(false)}
                  className="absolute top-1 right-1 text-slate-400 hover:text-white z-10 bg-black/40 p-0.5 rounded"
                  title="Close Ad"
                >
                  <X className="w-3 h-3" />
                </button>
                <div className="p-3 text-center border-b border-slate-800">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-400">Sponsored Ad</span>
                </div>
                <div className="p-4 space-y-3 text-center">
                  <p className="text-xs font-semibold leading-snug text-slate-100">
                    Latest Government Exam & Career Updates 2026
                  </p>
                  <div className="w-full h-44 bg-gradient-to-b from-blue-950 to-slate-900 rounded flex items-center justify-center border border-blue-900/50 p-2">
                    <span className="text-[11px] text-blue-200 font-medium leading-tight">100% Verified Job Alerts & Preparation</span>
                  </div>
                  <a
                    href="https://educationmasters.in"
                    target="_blank"
                    rel="noreferrer"
                    className="block bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs py-2 px-2 rounded transition"
                  >
                    Explore Updates
                  </a>
                </div>
              </div>
            </aside>
          )}

          {/* ================= CENTER MAIN ARTICLE CONTENT ================= */}
          <section className={`col-span-1 lg:col-span-8 ${showLeftAd ? 'xl:col-span-7' : 'xl:col-span-7'} space-y-4`}>

            {/* Top Breadcrumb Links */}
            <nav className="flex items-center space-x-1.5 text-xs text-slate-500 mb-2 overflow-x-auto whitespace-nowrap">
              <Link href="/" className="hover:text-blue-600 font-normal">Home</Link>
              <ChevronRight className="w-3 h-3 text-slate-400 shrink-0" />
              {isJobPage ? (
                <Link href="/jobs" className="hover:text-blue-600 font-normal">Jobs</Link>
              ) : isAdmitCardPage ? (
                <Link href="/admit-cards" className="hover:text-blue-600 font-normal">Admit Cards</Link>
              ) : isResultPage ? (
                <Link href="/results" className="hover:text-blue-600 font-normal">Results</Link>
              ) : article?.categorySlug ? (
                <Link href={`/category/${article.categorySlug}`} className="hover:text-blue-600 font-normal">
                  {article.category || 'Articles'}
                </Link>
              ) : (
                <Link href="/category/articles" className="hover:text-blue-600 font-normal">Articles</Link>
              )}
              <ChevronRight className="w-3 h-3 text-slate-400 shrink-0" />
              <span className="text-slate-600 font-normal truncate max-w-[400px]">
                {article?.title || 'Notification Details'}
              </span>
            </nav>

            {loading ? (
              <div className="space-y-4 sm:space-y-5 animate-pulse" aria-busy="true" aria-label="Loading article content">
                {/* 1. Title Skeleton */}
                <div className="space-y-2">
                  <div className="h-7 sm:h-8 bg-slate-200/80 rounded-md w-11/12" />
                  <div className="h-7 sm:h-8 bg-slate-200/80 rounded-md w-3/5" />
                </div>

                {/* 2. Byline Meta Skeleton */}
                <div className="flex flex-wrap items-center gap-2 sm:gap-3 py-1">
                  <div className="h-4 bg-slate-200/70 rounded w-28" />
                  <div className="h-4 bg-slate-200/70 rounded w-20" />
                  <div className="h-4 bg-slate-200/70 rounded w-32" />
                </div>

                {/* 3. Disclaimer Box Skeleton */}
                <div className="h-14 bg-amber-50/70 border border-amber-200/60 rounded-lg w-full" />

                {/* 4. Featured Banner Image Skeleton (Matches exact banner aspect ratio & height) */}
                <div className="w-full aspect-[16/9] sm:aspect-[21/9] md:aspect-[2/1] max-h-[460px] min-h-[200px] sm:min-h-[260px] md:min-h-[320px] bg-slate-200/80 rounded-xl border border-slate-200" />

                {/* 5. Social Share Bar Skeleton */}
                <div className="h-11 bg-slate-100/90 border border-slate-200/60 rounded-lg w-full flex items-center px-3 gap-2">
                  <div className="h-6 w-16 bg-slate-200 rounded-full" />
                  <div className="h-6 w-20 bg-slate-200 rounded-full" />
                  <div className="h-6 w-20 bg-slate-200 rounded-full" />
                </div>

                {/* 6. Overview Table / Content Skeleton */}
                <div className="space-y-3 pt-2">
                  <div className="h-6 bg-slate-200/80 rounded w-48" />
                  <div className="border border-slate-200 rounded-md p-4 space-y-3 bg-slate-50/50">
                    <div className="h-4 bg-slate-200/70 rounded w-full" />
                    <div className="h-4 bg-slate-200/70 rounded w-5/6" />
                    <div className="h-4 bg-slate-200/70 rounded w-4/6" />
                    <div className="h-4 bg-slate-200/70 rounded w-full" />
                  </div>
                </div>

                {/* 7. Article Body Lines */}
                <div className="space-y-2.5 pt-3">
                  <div className="h-4 bg-slate-200/60 rounded w-full" />
                  <div className="h-4 bg-slate-200/60 rounded w-11/12" />
                  <div className="h-4 bg-slate-200/60 rounded w-full" />
                  <div className="h-4 bg-slate-200/60 rounded w-4/5" />
                  <div className="h-4 bg-slate-200/60 rounded w-full" />
                  <div className="h-4 bg-slate-200/60 rounded w-3/4" />
                </div>
              </div>
            ) : article ? (
              <article className="space-y-3 sm:space-y-4 md:space-y-5" onClick={handleArticleContentClick}>

                {/* 2. Article Main Title */}
                <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-slate-900 leading-snug sm:leading-tight">
                  {article.title}
                </h1>

                {/* 3. Byline Meta: Author, Category, Posted Date & Status */}
                <div className="flex flex-wrap items-center gap-x-2 sm:gap-x-2.5 gap-y-1 text-xs sm:text-sm text-slate-600 font-normal">
                  <span className="inline-flex items-center">
                    By&nbsp;
                    <Link
                      href={`/author/${encodeURIComponent(
                        (typeof article.author === 'object'
                          ? article.author.slug || article.author.nicename || article.author.name
                          : article.author) || 'DigitalDeepak'
                      )}`}
                      className="font-bold text-slate-900 hover:text-blue-600 hover:underline transition"
                    >
                      {typeof article.author === 'object' ? article.author.name : article.author}
                    </Link>
                  </span>
                  <span className="text-slate-300 select-none">•</span>
                  <span className="inline-flex items-center">
                    In&nbsp;
                    {isJobPage ? (
                      <Link href="/jobs" className="text-slate-900 font-bold underline decoration-slate-300 hover:text-blue-600 transition">
                        Jobs
                      </Link>
                    ) : isAdmitCardPage ? (
                      <Link href="/admit-cards" className="text-slate-900 font-bold underline decoration-slate-300 hover:text-blue-600 transition">
                        Admit Card
                      </Link>
                    ) : isResultPage ? (
                      <Link href="/results" className="text-slate-900 font-bold underline decoration-slate-300 hover:text-blue-600 transition">
                        Result
                      </Link>
                    ) : (
                      <Link href={article.categorySlug ? `/category/${article.categorySlug}` : '/category/articles'} className="text-slate-900 font-bold underline decoration-slate-300 hover:text-blue-600 transition">
                        {(typeof article.category === 'object' ? article.category.name : article.category) || 'Articles'}
                      </Link>
                    )}
                  </span>
                  <span className="text-slate-300 select-none">•</span>
                  <span className="inline-flex items-center whitespace-nowrap">
                    Posted:&nbsp;<strong className="font-bold text-slate-900">{article.date}</strong>
                  </span>
                  {article.lastDate && (
                    <span className="inline-flex items-center whitespace-nowrap">
                      <span className="text-slate-300 mr-2 select-none">•</span>
                      Status:&nbsp;<strong className="font-bold text-slate-900">{article.lastDate}</strong>
                    </span>
                  )}
                </div>

                {/* 4. Official Disclaimer Box */}
                <div className="w-full p-2.5 sm:p-3.5 bg-[#fef9ed] border border-[#f5dfb8] rounded-lg text-xs text-[#8a5314] leading-relaxed">
                  <strong className="font-semibold">Disclaimer:</strong> The content shown on this page related to government jobs, admit cards and results is either sourced from various internet portals or directly from official government websites. We do not claim any affiliation or authority over this content. It is solely for information providing purposes.
                </div>

                {/* 5. Featured Banner Image (if available) - Reserved Aspect Ratio to prevent CLS */}
                {article.image && (
                  <div className="w-full my-2 sm:my-3.5 relative overflow-hidden rounded-xl border border-slate-200/90 bg-slate-100 shadow-2xs aspect-[16/9] sm:aspect-[21/9] md:aspect-[2/1] max-h-[460px] min-h-[200px] sm:min-h-[260px] md:min-h-[320px]">
                    {/* Background Shimmer Placeholder while downloading */}
                    <div
                      className="absolute inset-0 bg-gradient-to-r from-slate-100 via-slate-200/70 to-slate-100 animate-pulse pointer-events-none"
                      aria-hidden="true"
                    />
                    <img
                      src={article.image}
                      alt={article.title}
                      loading="eager"
                      fetchPriority="high"
                      decoding="async"
                      onLoad={() => setIsBannerLoaded(true)}
                      className="w-full h-full h-cover max-h-[440px] relative z-10"
                      onError={(e) => {
                        setIsBannerLoaded(true);
                        if (!e.currentTarget.dataset.fallback) {
                          e.currentTarget.dataset.fallback = 'true';
                          e.currentTarget.src = '/logo.webp';
                        } else {
                          e.currentTarget.style.display = 'none';
                        }
                      }}
                    />
                  </div>
                )}

                {/* 6. Professional Social Share Bar (Icons expand on hover to show label) */}
                <div className="flex flex-wrap items-center justify-between gap-2 sm:gap-3 py-1.5 sm:py-2.5 border-y border-slate-200/80 my-2 sm:my-3 bg-slate-50/60 px-2.5 sm:px-3 rounded-lg">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mr-1">Share:</span>

                    {/* WhatsApp */}
                    <a
                      href={`https://api.whatsapp.com/send?text=${encodeURIComponent(article.title + ' ' + currentUrl)}`}
                      target="_blank"
                      rel="noreferrer"
                      className="group inline-flex items-center justify-center h-8 px-2.5 bg-[#25D366] hover:bg-[#1eb956] text-white text-xs font-semibold rounded-full shadow-2xs hover:shadow-md transition-all duration-300 ease-out transform hover:-translate-y-0.5 active:scale-95 cursor-pointer"
                      title="Share on WhatsApp"
                    >
                      <svg className="w-3.5 h-3.5 fill-current shrink-0 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-1.157 4.228 4.228-1.157z" /></svg>
                      <span className="max-w-0 opacity-0 overflow-hidden whitespace-nowrap transition-all duration-300 ease-out group-hover:max-w-24 group-hover:opacity-100 group-hover:ml-1.5">
                        WhatsApp
                      </span>
                    </a>

                    {/* Telegram */}
                    <a
                      href={`https://t.me/share/url?url=${encodeURIComponent(currentUrl)}&text=${encodeURIComponent(article.title)}`}
                      target="_blank"
                      rel="noreferrer"
                      className="group inline-flex items-center justify-center h-8 px-2.5 bg-[#0088cc] hover:bg-[#0077b5] text-white text-xs font-semibold rounded-full shadow-2xs hover:shadow-md transition-all duration-300 ease-out transform hover:-translate-y-0.5 active:scale-95 cursor-pointer"
                      title="Share on Telegram"
                    >
                      <svg className="w-3.5 h-3.5 fill-current shrink-0 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24"><path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.121l-6.871 4.326-2.962-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.832.942z" /></svg>
                      <span className="max-w-0 opacity-0 overflow-hidden whitespace-nowrap transition-all duration-300 ease-out group-hover:max-w-24 group-hover:opacity-100 group-hover:ml-1.5">
                        Telegram
                      </span>
                    </a>

                    {/* Facebook */}
                    <a
                      href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(currentUrl)}`}
                      target="_blank"
                      rel="noreferrer"
                      className="group inline-flex items-center justify-center h-8 px-2.5 bg-[#1877F2] hover:bg-[#166fe5] text-white text-xs font-semibold rounded-full shadow-2xs hover:shadow-md transition-all duration-300 ease-out transform hover:-translate-y-0.5 active:scale-95 cursor-pointer"
                      title="Share on Facebook"
                    >
                      <svg className="w-3.5 h-3.5 fill-current shrink-0 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" /></svg>
                      <span className="max-w-0 opacity-0 overflow-hidden whitespace-nowrap transition-all duration-300 ease-out group-hover:max-w-24 group-hover:opacity-100 group-hover:ml-1.5">
                        Facebook
                      </span>
                    </a>

                    {/* Twitter / X */}
                    <a
                      href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(article.title + ' ' + currentUrl)}`}
                      target="_blank"
                      rel="noreferrer"
                      className="group inline-flex items-center justify-center h-8 px-2.5 bg-slate-900 hover:bg-black text-white text-xs font-semibold rounded-full shadow-2xs hover:shadow-md transition-all duration-300 ease-out transform hover:-translate-y-0.5 active:scale-95 cursor-pointer"
                      title="Share on X / Twitter"
                    >
                      <svg className="w-3.5 h-3.5 fill-current shrink-0 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" /></svg>
                      <span className="max-w-0 opacity-0 overflow-hidden whitespace-nowrap transition-all duration-300 ease-out group-hover:max-w-24 group-hover:opacity-100 group-hover:ml-1.5">
                        Twitter
                      </span>
                    </a>
                  </div>

                  {/* Copy Link Button */}
                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className="group inline-flex items-center justify-center h-8 px-2.5 bg-white hover:bg-slate-50 border border-slate-300 hover:border-slate-400 text-slate-700 text-xs font-semibold rounded-full shadow-2xs hover:shadow-md transition-all duration-300 ease-out transform hover:-translate-y-0.5 active:scale-95 cursor-pointer"
                    title={copiedLink ? 'Link Copied!' : 'Copy Link'}
                  >
                    {copiedLink ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    ) : (
                      <Copy className="w-3.5 h-3.5 text-slate-600 shrink-0 transition-transform duration-300 group-hover:scale-110" />
                    )}
                    <span
                      className={`overflow-hidden whitespace-nowrap transition-all duration-300 ease-out ${copiedLink
                        ? 'max-w-24 opacity-100 ml-1.5 text-emerald-600 font-semibold'
                        : 'max-w-0 opacity-0 group-hover:max-w-24 group-hover:opacity-100 group-hover:ml-1.5'
                        }`}
                    >
                      {copiedLink ? 'Copied!' : 'Copy Link'}
                    </span>
                  </button>
                </div>

                {/* ========================================================================= */}
                {/* 7. DEDICATED RESULT & ADMIT CARD VIEW - MATCHING PRODUCTION SCREENSHOTS */}
                {/* ========================================================================= */}
                {(article.isResult || article.isAdmitCard) && article.resultDetails ? (
                  <div className="space-y-6 pt-2">

                    {/* SECTION 1: ABOUT [EXAM NAME] RESULT */}
                    <div>
                      <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mb-3 border-b border-slate-100 pb-2">
                        About {article.resultDetails.examName} {article.isResult ? 'Result' : 'Admit Card'}
                      </h2>
                      {article.resultDetails.description ? (
                        <div
                          className="article-raw-html text-slate-700 text-base leading-relaxed space-y-3 font-normal"
                          dangerouslySetInnerHTML={{ __html: article.resultDetails.description }}
                        />
                      ) : (
                        <p className="text-slate-700 text-base leading-relaxed">
                          {article.resultDetails.deptName} will release the {article.resultDetails.examName} {article.isResult ? 'Result 2026' : 'Admit Card 2026'} for candidates who appeared in the examination process under {article.resultDetails.postName}.
                        </p>
                      )}
                    </div>

                    {/* SECTION 2: OVERVIEW TABLE */}
                    <div className="pt-2">
                      <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mb-3">
                        {article.resultDetails.examName} {article.isResult ? 'Result' : 'Admit Card'} – Overview
                      </h2>
                      <div className="overflow-x-auto border border-slate-200 rounded-md shadow-2xs">
                        <table className="w-full text-xs sm:text-sm text-left border-collapse">
                          <tbody className="divide-y divide-slate-200 bg-white">
                            <tr className="hover:bg-slate-50 transition">
                              <th className="p-3.5 bg-[#f0f3fa] font-semibold text-slate-800 w-1/3 sm:w-1/4 border-r border-slate-200">
                                Name of Exam
                              </th>
                              <td className="p-3.5 font-normal text-slate-900">
                                {article.resultDetails.examName}
                              </td>
                            </tr>
                            <tr className="hover:bg-slate-50 transition">
                              <th className="p-3.5 bg-[#f0f3fa] font-semibold text-slate-800 border-r border-slate-200">
                                Conducting Department
                              </th>
                              <td className="p-3.5 font-normal text-slate-900">
                                {article.resultDetails.deptName}
                              </td>
                            </tr>
                            <tr className="hover:bg-slate-50 transition">
                              <th className="p-3.5 bg-[#f0f3fa] font-semibold text-slate-800 border-r border-slate-200">
                                Post Name
                              </th>
                              <td className="p-3.5 font-normal text-slate-900 leading-snug">
                                {article.resultDetails.postName}
                              </td>
                            </tr>
                            <tr className="hover:bg-slate-50 transition">
                              <th className="p-3.5 bg-[#f0f3fa] font-semibold text-slate-800 border-r border-slate-200">
                                Exam Date
                              </th>
                              <td className="p-3.5 font-normal text-slate-900">
                                {article.resultDetails.examDate}
                              </td>
                            </tr>
                            <tr className="hover:bg-slate-50 transition">
                              <th className="p-3.5 bg-[#f0f3fa] font-semibold text-slate-800 border-r border-slate-200">
                                Exam Time
                              </th>
                              <td className="p-3.5 font-normal text-slate-900">
                                {article.resultDetails.examTime}
                              </td>
                            </tr>
                            <tr className="hover:bg-slate-50 transition">
                              <th className="p-3.5 bg-[#f0f3fa] font-semibold text-slate-800 border-r border-slate-200">
                                Exam Mode
                              </th>
                              <td className="p-3.5 font-normal text-slate-900">
                                {article.resultDetails.examMode}
                              </td>
                            </tr>
                            <tr className="hover:bg-slate-50 transition">
                              <th className="p-3.5 bg-[#f0f3fa] font-semibold text-slate-800 border-r border-slate-200">
                                Official Website
                              </th>
                              <td className="p-3.5 font-medium text-blue-600">
                                {article.resultDetails.officialWebsite ? (
                                  <a
                                    href={article.resultDetails.officialWebsite}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="hover:underline break-all"
                                  >
                                    {article.resultDetails.officialWebsite}
                                  </a>
                                ) : (
                                  <span className="text-slate-500 font-normal">Check Official Notification</span>
                                )}
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>

                    {/* SECTION 3: DIRECT VIEW RESULT LINK CALLOUT BANNER */}
                    <div className="my-6 p-6 sm:p-8 bg-[#1d68e1] text-white rounded-lg text-center shadow-md space-y-3 direct-link-banner" data-editor-content="true">
                      <h3 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                        {article.isResult ? 'Direct View Result Link' : 'Direct Download Admit Card Link'}
                      </h3>
                      <p className="text-xs sm:text-sm text-blue-100 max-w-xl mx-auto font-normal">
                        Click the button below to visit the official website and {article.isResult ? 'view/download your result' : 'download your admit card'}
                      </p>
                      <div className="pt-2">
                        <a
                          href={article.resultDetails.downUrl || article.resultDetails.officialWebsite || '#'}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-block bg-[#ffc107] hover:bg-[#ffb300] active:scale-95 text-slate-900 font-extrabold text-sm sm:text-base px-8 py-3 rounded-md shadow hover:shadow-md transition duration-200"
                        >
                          {article.isResult ? 'View Result' : 'Download Admit Card'}
                        </a>
                      </div>
                    </div>

                    {/* SECTION 4: HOW TO VIEW/DOWNLOAD RESULT */}
                    <div className="pt-2 space-y-3">
                      <h2 className="text-xl sm:text-2xl font-bold text-slate-900 border-b border-slate-100 pb-2">
                        How to {article.isResult ? 'View/Download' : 'Download'} {article.resultDetails.examName} {article.isResult ? 'Result' : 'Admit Card'}
                      </h2>

                      {/* Clean In-Content Ad Frame */}
                      <div className="my-4 p-4 sm:p-5 bg-gradient-to-r from-slate-50 to-blue-50/40 border border-slate-200/90 rounded-lg flex flex-col sm:flex-row items-center justify-between gap-4">
                        <div className="space-y-1">
                          <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest bg-blue-100 px-2 py-0.5 rounded">
                            Official Exam Portal
                          </span>
                          <h4 className="text-sm font-bold text-slate-800">
                            Download Scorecard & Merit List PDF Online
                          </h4>
                          <p className="text-xs text-slate-600">
                            Keep your registration number and DOB ready for quick access.
                          </p>
                        </div>
                        <a
                          href={article.resultDetails.downUrl || '#'}
                          target="_blank"
                          rel="noreferrer"
                          className="shrink-0 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs px-4 py-2 rounded shadow-2xs transition"
                        >
                          Learn More →
                        </a>
                      </div>

                      {/* Steps List */}
                      {article.resultDetails.instDownItems && article.resultDetails.instDownItems.length > 0 ? (
                        <ol className="list-decimal pl-5 space-y-2.5 text-sm sm:text-base text-slate-700 font-normal leading-relaxed">
                          {article.resultDetails.instDownItems.map((step, idx) => (
                            <li key={idx} className="pl-1">
                              {step}
                            </li>
                          ))}
                        </ol>
                      ) : article.resultDetails.instDown ? (
                        <div
                          className="article-raw-html text-slate-700 text-sm sm:text-base leading-relaxed space-y-2 font-normal"
                          dangerouslySetInnerHTML={{ __html: article.resultDetails.instDown }}
                        />
                      ) : (
                        <ol className="list-decimal pl-5 space-y-2.5 text-sm sm:text-base text-slate-700 font-normal leading-relaxed">
                          <li className="pl-1">Visit the official {article.resultDetails.deptName} website.</li>
                          <li className="pl-1">Open the Careers / Recruitment / Result section.</li>
                          <li className="pl-1">Find &quot;{article.resultDetails.examName} Result 2026&quot;.</li>
                          <li className="pl-1">Click on the result or shortlisted candidates link when released.</li>
                          <li className="pl-1">Enter your Registration Number and Password/Date of Birth, if login is required.</li>
                          <li className="pl-1">Submit the details and view your result status.</li>
                          <li className="pl-1">Download and save the result PDF or scorecard for future reference.</li>
                        </ol>
                      )}
                    </div>

                    {/* SECTION 5: DETAILS MENTIONED */}
                    <div className="pt-2 space-y-3">
                      <h2 className="text-xl sm:text-2xl font-bold text-slate-900 border-b border-slate-100 pb-2">
                        Details Mentioned in {article.resultDetails.examName}
                      </h2>

                      {article.resultDetails.instImplItems && article.resultDetails.instImplItems.length > 0 ? (
                        <ul className="list-disc pl-5 space-y-2.5 text-sm sm:text-base text-slate-700 font-normal leading-relaxed">
                          {article.resultDetails.instImplItems.map((point, idx) => (
                            <li key={idx} className="pl-1">
                              {point}
                            </li>
                          ))}
                        </ul>
                      ) : article.resultDetails.instImpl ? (
                        <div
                          className="article-raw-html text-slate-700 text-sm sm:text-base leading-relaxed space-y-2 font-normal"
                          dangerouslySetInnerHTML={{ __html: article.resultDetails.instImpl }}
                        />
                      ) : (
                        <ul className="list-disc pl-5 space-y-2.5 text-sm sm:text-base text-slate-700 font-normal leading-relaxed">
                          <li className="pl-1">Check your name, roll number, and qualifying status carefully.</li>
                          <li className="pl-1">Download a copy of the result for future reference.</li>
                          <li className="pl-1">Check the next selection stage mentioned in the result notification.</li>
                          <li className="pl-1">Keep your original documents ready for Document Verification (DV).</li>
                          <li className="pl-1">Regularly check the official recruitment page for further selection rounds.</li>
                        </ul>
                      )}
                    </div>

                    {/* SECTION 6: FAQS */}
                    {article.resultDetails.faqItems && article.resultDetails.faqItems.length > 0 && (
                      <div className="pt-3 space-y-4">
                        <h2 className="text-xl sm:text-2xl font-bold text-slate-900 border-b border-slate-100 pb-2">
                          Frequently Asked Questions (FAQs)
                        </h2>

                        <div className="space-y-4">
                          {article.resultDetails.faqItems.map((faq, idx) => (
                            <div key={idx} className="space-y-1">
                              <p className="font-bold text-slate-900 text-sm sm:text-base">
                                Q{idx + 1}. {faq.question}
                              </p>
                              <p className="text-slate-700 text-sm sm:text-base leading-relaxed font-normal">
                                Answer: {faq.answer}
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                  </div>
                ) : (
                  /* ========================================================================= */
                  /* 7. GENERAL / JOB ARTICLE VIEW */
                  /* ========================================================================= */
                  <div className="w-full text-slate-700 text-sm sm:text-base leading-relaxed space-y-4 font-normal">
                    {article.content ? (
                      <div
                        className="article-raw-html w-full text-slate-700 text-sm sm:text-base leading-relaxed space-y-4"
                        dangerouslySetInnerHTML={{ __html: article.content }}
                      />
                    ) : null}

                    {/* Job Highlights Table for Job Articles */}
                    {article.isJob && article.jobDetails && !article.content?.includes('<table') && (
                      <div className="my-6 space-y-3">
                        <h2 className="text-xl font-bold text-slate-900 border-b border-slate-200 pb-2">
                          {article.title} Job Highlights:
                        </h2>
                        <div className="overflow-x-auto border border-slate-200 rounded-md">
                          <table className="w-full text-xs sm:text-sm text-left border-collapse">
                            <tbody className="divide-y divide-slate-200 bg-white">
                              <tr className="hover:bg-slate-50">
                                <th className="p-3 bg-slate-50 font-semibold text-slate-700 w-1/3 border-r border-slate-200">Name of Exam</th>
                                <td className="p-3 font-normal text-slate-900">{article.jobDetails.postName}</td>
                              </tr>
                              <tr className="hover:bg-slate-50">
                                <th className="p-3 bg-slate-50 font-semibold text-slate-700 border-r border-slate-200">No. of Seats</th>
                                <td className="p-3 font-normal text-slate-900">{article.jobDetails.totalVacancies}</td>
                              </tr>
                              <tr className="hover:bg-slate-50">
                                <th className="p-3 bg-slate-50 font-semibold text-slate-700 border-r border-slate-200">Job Location</th>
                                <td className="p-3 font-normal text-slate-900">
                                  <StateLink state={article.state || article.jobDetails.jobLocation} dept={article.dept} fallback={article.jobDetails.jobLocation} />
                                </td>
                              </tr>
                              <tr className="hover:bg-slate-50">
                                <th className="p-3 bg-slate-50 font-semibold text-slate-700 border-r border-slate-200">Notification Release Date</th>
                                <td className="p-3 font-normal text-slate-900">{article.jobDetails.releaseDate || article.date}</td>
                              </tr>
                              <tr className="hover:bg-slate-50">
                                <th className="p-3 bg-slate-50 font-semibold text-slate-700 border-r border-slate-200">Online Application Start Date</th>
                                <td className="p-3 font-normal text-slate-900">{article.jobDetails.startDate || article.date}</td>
                              </tr>
                              <tr className="hover:bg-slate-50">
                                <th className="p-3 bg-slate-50 font-semibold text-slate-700 border-r border-slate-200">Last Date to Apply</th>
                                <td className="p-3 font-normal text-slate-900">{article.jobDetails.endDate || 'Check Notification'}</td>
                              </tr>
                              <tr className="hover:bg-slate-50">
                                <th className="p-3 bg-slate-50 font-semibold text-slate-700 border-r border-slate-200">Prelims Exam Date</th>
                                <td className="p-3 font-normal text-slate-500">{article.jobDetails.examDate}</td>
                              </tr>
                              <tr className="hover:bg-slate-50">
                                <th className="p-3 bg-slate-50 font-semibold text-slate-700 border-r border-slate-200">Minimum age limit</th>
                                <td className="p-3 font-normal text-slate-500">{article.jobDetails.minAge}</td>
                              </tr>
                              <tr className="hover:bg-slate-50">
                                <th className="p-3 bg-slate-50 font-semibold text-slate-700 border-r border-slate-200">Maximum age limit</th>
                                <td className="p-3 font-normal text-slate-500">{article.jobDetails.maxAge}</td>
                              </tr>
                              <tr className="hover:bg-slate-50">
                                <th className="p-3 bg-slate-50 font-semibold text-slate-700 border-r border-slate-200">Notification Release Link</th>
                                <td className="p-3 font-medium text-blue-600">
                                  {article.jobDetails.officialLink ? (
                                    <a href={article.jobDetails.officialLink} target="_blank" rel="noreferrer" className="hover:underline">Click here</a>
                                  ) : 'N/A'}
                                </td>
                              </tr>
                              <tr className="hover:bg-slate-50">
                                <th className="p-3 bg-slate-50 font-semibold text-slate-700 border-r border-slate-200">Direct Online Application Link</th>
                                <td className="p-3 font-medium text-blue-600">
                                  {article.jobDetails.applyLink ? (
                                    <a href={article.jobDetails.applyLink} target="_blank" rel="noreferrer" className="hover:underline">Apply now</a>
                                  ) : 'N/A'}
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* 8. Government Jobs & GK Updates Channel Follow Section */}
                <div className="my-6 space-y-4 font-normal pt-2">
                  <p className="font-bold text-slate-900 text-sm sm:text-base">
                    सरकारी नौकरियों, जीके अपडेट्स और करेंट अफेयर्स की ताज़ा जानकारी सबसे पहले पाने के लिए:
                  </p>
                  <div className="space-y-3 text-xs sm:text-sm">
                    <div>
                      <p className="font-bold text-slate-900 text-sm sm:text-base">हमारे WhatsApp चैनल को फॉलो करें:</p>
                      <a
                        href="https://whatsapp.com/channel/0029Vb6sjZz0wajwDXcd5B0U"
                        target="_blank"
                        rel="noreferrer"
                        className="text-[#25D366] font-bold text-sm sm:text-base underline hover:opacity-80 break-all inline-block mt-0.5"
                      >
                        https://whatsapp.com/channel/0029Vb6sjZz0wajwDXcd5B0U
                      </a>
                    </div>

                    <div>
                      <p className="font-bold text-slate-900 text-sm sm:text-base">हमारे Telegram चैनल को फॉलो करें:</p>
                      <a
                        href="https://t.me/educationmastersin"
                        target="_blank"
                        rel="noreferrer"
                        className="text-[#0088cc] font-bold text-sm sm:text-base underline hover:opacity-80 break-all inline-block mt-0.5"
                      >
                        https://t.me/educationmastersin
                      </a>
                    </div>

                    <div>
                      <p className="font-bold text-slate-900 text-sm sm:text-base">हमारे Facebook Page को फॉलो करें:</p>
                      <a
                        href="https://www.facebook.com/educationmastersindia"
                        target="_blank"
                        rel="noreferrer"
                        className="text-[#1877F2] font-bold text-sm sm:text-base underline hover:opacity-80 break-all inline-block mt-0.5"
                      >
                        https://www.facebook.com/educationmastersindia
                      </a>
                    </div>
                  </div>
                </div>

                {/* 9. AddressGuru / Free Classified Banner Ad Space */}
                <div className="my-6 w-full bg-gradient-to-r from-slate-900 via-purple-950 to-slate-900 text-white rounded-md p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm border border-purple-900/40">
                  <div className="space-y-1 text-center sm:text-left">
                    <div className="flex items-center justify-center sm:justify-start space-x-2">
                      <span className="bg-amber-400 text-slate-950 font-extrabold text-[10px] px-2 py-0.5 rounded">FREE</span>
                      <span className="font-bold text-sm sm:text-base tracking-wide text-white">www.addressguru.in</span>
                    </div>
                    <p className="text-xs text-purple-200">
                      FREE CLASSIFIED INDIA • POST FREE AD • LOCAL DIRECTORY
                    </p>
                  </div>
                  <a
                    href="https://addressguru.in"
                    target="_blank"
                    rel="noreferrer"
                    className="bg-amber-400 hover:bg-amber-500 text-slate-950 font-bold text-xs px-5 py-2.5 rounded shadow transition"
                  >
                    POST FREE AD →
                  </a>
                </div>

                {/* 10. Share this Post Box with Circular Buttons & Discover More */}
                <div className="my-6 space-y-3">
                  <div>
                    <h3 className="text-xl font-bold text-slate-900">Share this Post</h3>
                    <p className="text-xs text-slate-500 font-normal mt-0.5">(इस पोस्ट को अपने दोस्तों के साथ शेयर करना ना भूले)</p>
                  </div>

                  {/* Expandable Social Share Buttons */}
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    {/* WhatsApp */}
                    <a
                      href={`https://api.whatsapp.com/send?text=${encodeURIComponent(article.title + ' ' + currentUrl)}`}
                      target="_blank"
                      rel="noreferrer"
                      className="group inline-flex items-center justify-center h-9 px-2.5 rounded-full bg-[#25D366] hover:bg-[#1eb956] text-white shadow-2xs hover:shadow-md transition-all duration-300 ease-out transform hover:-translate-y-0.5 active:scale-95 cursor-pointer"
                      title="WhatsApp"
                    >
                      <svg className="w-4 h-4 fill-current shrink-0 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-1.157 4.228 4.228-1.157z" /></svg>
                      <span className="max-w-0 opacity-0 overflow-hidden whitespace-nowrap text-xs font-semibold transition-all duration-300 ease-out group-hover:max-w-24 group-hover:opacity-100 group-hover:ml-1.5">
                        WhatsApp
                      </span>
                    </a>

                    {/* Telegram */}
                    <a
                      href={`https://t.me/share/url?url=${encodeURIComponent(currentUrl)}&text=${encodeURIComponent(article.title)}`}
                      target="_blank"
                      rel="noreferrer"
                      className="group inline-flex items-center justify-center h-9 px-2.5 rounded-full bg-[#0088cc] hover:bg-[#0077b5] text-white shadow-2xs hover:shadow-md transition-all duration-300 ease-out transform hover:-translate-y-0.5 active:scale-95 cursor-pointer"
                      title="Telegram"
                    >
                      <svg className="w-4 h-4 fill-current shrink-0 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24"><path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.121l-6.871 4.326-2.962-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.832.942z" /></svg>
                      <span className="max-w-0 opacity-0 overflow-hidden whitespace-nowrap text-xs font-semibold transition-all duration-300 ease-out group-hover:max-w-24 group-hover:opacity-100 group-hover:ml-1.5">
                        Telegram
                      </span>
                    </a>

                    {/* Facebook */}
                    <a
                      href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(currentUrl)}`}
                      target="_blank"
                      rel="noreferrer"
                      className="group inline-flex items-center justify-center h-9 px-2.5 rounded-full bg-[#1877F2] hover:bg-[#166fe5] text-white shadow-2xs hover:shadow-md transition-all duration-300 ease-out transform hover:-translate-y-0.5 active:scale-95 cursor-pointer"
                      title="Facebook"
                    >
                      <svg className="w-4 h-4 fill-current shrink-0 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" /></svg>
                      <span className="max-w-0 opacity-0 overflow-hidden whitespace-nowrap text-xs font-semibold transition-all duration-300 ease-out group-hover:max-w-24 group-hover:opacity-100 group-hover:ml-1.5">
                        Facebook
                      </span>
                    </a>

                    {/* LinkedIn */}
                    <a
                      href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(currentUrl)}`}
                      target="_blank"
                      rel="noreferrer"
                      className="group inline-flex items-center justify-center h-9 px-2.5 rounded-full bg-[#0077b5] hover:bg-[#00669c] text-white shadow-2xs hover:shadow-md transition-all duration-300 ease-out transform hover:-translate-y-0.5 active:scale-95 cursor-pointer"
                      title="LinkedIn"
                    >
                      <svg className="w-4 h-4 fill-current shrink-0 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.262-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" /></svg>
                      <span className="max-w-0 opacity-0 overflow-hidden whitespace-nowrap text-xs font-semibold transition-all duration-300 ease-out group-hover:max-w-24 group-hover:opacity-100 group-hover:ml-1.5">
                        LinkedIn
                      </span>
                    </a>

                    {/* Twitter */}
                    <a
                      href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(article.title + ' ' + currentUrl)}`}
                      target="_blank"
                      rel="noreferrer"
                      className="group inline-flex items-center justify-center h-9 px-2.5 rounded-full bg-slate-900 hover:bg-black text-white shadow-2xs hover:shadow-md transition-all duration-300 ease-out transform hover:-translate-y-0.5 active:scale-95 cursor-pointer"
                      title="Twitter / X"
                    >
                      <svg className="w-4 h-4 fill-current shrink-0 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" /></svg>
                      <span className="max-w-0 opacity-0 overflow-hidden whitespace-nowrap text-xs font-semibold transition-all duration-300 ease-out group-hover:max-w-24 group-hover:opacity-100 group-hover:ml-1.5">
                        Twitter
                      </span>
                    </a>

                    {/* Reddit */}
                    <a
                      href={`https://reddit.com/submit?url=${encodeURIComponent(currentUrl)}&title=${encodeURIComponent(article.title)}`}
                      target="_blank"
                      rel="noreferrer"
                      className="group inline-flex items-center justify-center h-9 px-2.5 rounded-full bg-[#FF4500] hover:bg-[#e03d00] text-white shadow-2xs hover:shadow-md transition-all duration-300 ease-out transform hover:-translate-y-0.5 active:scale-95 cursor-pointer"
                      title="Reddit"
                    >
                      <svg className="w-4 h-4 fill-current shrink-0 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24"><path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.01 4.744c.688 0 1.25.561 1.25 1.249a1.25 1.25 0 0 1-2.498.056l-2.597-.547-.8 3.747c1.824.07 3.48.632 4.674 1.488.308-.309.73-.491 1.207-.491.968 0 1.754.786 1.754 1.754 0 .716-.435 1.333-1.01 1.614a3.111 3.111 0 0 1 .042.52c0 2.694-3.13 4.87-7.004 4.87-3.874 0-7.004-2.176-7.004-4.87 0-.183.015-.366.043-.534A1.748 1.748 0 0 1 4.028 12c0-.968.786-1.754 1.754-1.754.463 0 .898.196 1.207.49 1.207-.883 2.878-1.43 4.744-1.487l.885-4.182a.342.342 0 0 1 .14-.197.35.35 0 0 1 .238-.042l2.906.617a1.214 1.214 0 0 1 1.108-.701zM9.25 12C8.561 12 8 12.562 8 13.25c0 .687.561 1.248 1.25 1.248.687 0 1.248-.561 1.248-1.249 0-.688-.561-1.249-1.249-1.249zm5.5 0c-.687 0-1.248.561-1.248 1.25 0 .687.561 1.248 1.249 1.248.688 0 1.249-.561 1.249-1.249 0-.687-.562-1.249-1.25-1.249zm-5.466 3.99a.327.327 0 0 0-.231.094.33.33 0 0 0 0 .463c.842.842 2.484.913 2.961.913.477 0 2.105-.056 2.961-.913a.361.361 0 0 0 .029-.463.33.33 0 0 0-.464 0c-.547.533-1.684.73-2.512.73-.828 0-1.979-.196-2.512-.73a.326.326 0 0 0-.232-.095z" /></svg>
                      <span className="max-w-0 opacity-0 overflow-hidden whitespace-nowrap text-xs font-semibold transition-all duration-300 ease-out group-hover:max-w-24 group-hover:opacity-100 group-hover:ml-1.5">
                        Reddit
                      </span>
                    </a>
                  </div>

                </div>

                {/* 11. Others Category Jobs Grid */}
                <div className="my-8 pt-4 border-t border-slate-200">
                  <h3 className="text-xl font-bold text-slate-900 mb-4">
                    Others Category Jobs
                  </h3>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
                    {relatedJobs.map((job, idx) => (
                      <Link
                        key={job.id || idx}
                        href={`/job/${job.slug}`}
                        className="group bg-white border border-slate-200 rounded-md overflow-hidden hover:shadow-md transition duration-200 flex flex-col"
                      >
                        <div className="w-full h-28 sm:h-32 bg-slate-100 overflow-hidden relative">
                          <img
                            src={job.image}
                            alt={job.title}
                            loading="lazy"
                            decoding="async"
                            className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                            onError={(e) => {
                              if (!e.currentTarget.dataset.fallback) {
                                e.currentTarget.dataset.fallback = 'true';
                                e.currentTarget.src = '/logo.webp';
                              } else {
                                e.currentTarget.style.display = 'none';
                              }
                            }}
                          />
                        </div>
                        <div className="p-2.5 flex-1 flex flex-col justify-between space-y-1">
                          <h4 className="text-xs sm:text-sm font-bold text-slate-900 group-hover:text-blue-600 line-clamp-2 leading-snug">
                            {job.title}
                          </h4>
                          <span className="text-[11px] text-blue-600 font-semibold pt-1">
                            Apply Now →
                          </span>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>

                {/* 12. Professional Author Box Matching Live Reference Image & Linked Social Profiles */}
                {article.author && !article.content?.includes('class="author') && (
                  <div className="my-8 p-4 sm:p-5 bg-gradient-to-br from-slate-50/95 to-[#f8f9fa] border border-slate-200/90 rounded-xl flex flex-col sm:flex-row items-center sm:items-start text-center sm:text-left gap-4 sm:gap-5 shadow-2xs">
                    {/* Left Square Avatar Frame */}
                    <Link
                      href={`/author/${encodeURIComponent(
                        (typeof article.author === 'object'
                          ? article.author.slug || article.author.nicename || article.author.name
                          : article.author) || 'DigitalDeepak'
                      )}`}
                      className="w-20 h-20 sm:w-24 sm:h-24 shrink-0 bg-slate-100 border border-slate-200/90 rounded-xl p-1 shadow-xs overflow-hidden block group hover:border-blue-400 transition-all duration-300"
                      title="View Author Profile"
                    >
                      <img
                        src={typeof article.author === 'object' ? article.author.image : 'https://educationmasters.in/assets/img/defaults/user.png'}
                        alt={typeof article.author === 'object' ? article.author.name : article.author}
                        loading="lazy"
                        decoding="async"
                        className="w-full h-full object-cover rounded-lg group-hover:scale-105 transition-transform duration-300"
                        onError={(e) => {
                          if (!e.currentTarget.dataset.fallback) {
                            e.currentTarget.dataset.fallback = 'true';
                            e.currentTarget.src = '/logo.webp';
                          } else {
                            e.currentTarget.style.display = 'none';
                          }
                        }}
                      />
                    </Link>

                    {/* Right Bio Content */}
                    <div className="flex-1 space-y-2 min-w-0">
                      <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                        <Link
                          href={`/author/${encodeURIComponent(
                            (typeof article.author === 'object'
                              ? article.author.slug || article.author.nicename || article.author.name
                              : article.author) || 'DigitalDeepak'
                          )}`}
                          className="text-lg font-extrabold text-slate-900 hover:text-blue-600 hover:underline leading-tight transition inline-block"
                        >
                          {typeof article.author === 'object' ? article.author.name : article.author}
                        </Link>
                        {typeof article.author === 'object' && article.author.role && (
                          <span className="bg-orange-50 text-orange-700 border border-orange-200/80 font-bold text-[10px] px-2.5 py-0.5 rounded-full capitalize leading-none">
                            {article.author.role}
                          </span>
                        )}
                        {typeof article.author === 'object' && article.author.nicename && (
                          <span className="text-xs text-slate-400 font-medium">
                            @{article.author.nicename}
                          </span>
                        )}
                      </div>

                      <p className="text-xs sm:text-sm text-slate-600 font-normal leading-relaxed">
                        {typeof article.author === 'object' && article.author.bio ? article.author.bio : 'Content Writer at Education Masters, passionate about creating informative, SEO-friendly, and student-focused educational content covering government jobs, entrance exams, admissions, results, and career guidance.'}
                      </p>

                      {/* Social Media & Contact Links Row */}
                      {typeof article.author === 'object' && (article.author.website || article.author.twitter || article.author.facebook || article.author.instagram || article.author.linkedin || article.author.youtube) && (
                        <div className="flex items-center justify-center sm:justify-start gap-2 pt-1.5 flex-wrap">
                          {article.author.website && (
                            <a
                              href={formatSocialUrl('website', article.author.website)}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="w-7 h-7 rounded-lg bg-white hover:bg-blue-50 text-slate-500 hover:text-blue-600 border border-slate-200 shadow-2xs flex items-center justify-center transition hover:scale-110"
                              title="Official Website"
                            >
                              <Globe className="w-3.5 h-3.5" />
                            </a>
                          )}
                          {article.author.twitter && (
                            <a
                              href={formatSocialUrl('twitter', article.author.twitter)}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="w-7 h-7 rounded-lg bg-white hover:bg-sky-50 text-slate-500 hover:text-sky-500 border border-slate-200 shadow-2xs flex items-center justify-center transition hover:scale-110"
                              title="Twitter / X"
                            >
                              <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                                <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                              </svg>
                            </a>
                          )}
                          {article.author.facebook && (
                            <a
                              href={formatSocialUrl('facebook', article.author.facebook)}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="w-7 h-7 rounded-lg bg-white hover:bg-blue-50 text-slate-500 hover:text-blue-600 border border-slate-200 shadow-2xs flex items-center justify-center transition hover:scale-110"
                              title="Facebook"
                            >
                              <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                              </svg>
                            </a>
                          )}
                          {article.author.instagram && (
                            <a
                              href={formatSocialUrl('instagram', article.author.instagram)}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="w-7 h-7 rounded-lg bg-white hover:bg-pink-50 text-slate-500 hover:text-pink-600 border border-slate-200 shadow-2xs flex items-center justify-center transition hover:scale-110"
                              title="Instagram"
                            >
                              <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                              </svg>
                            </a>
                          )}
                          {article.author.linkedin && (
                            <a
                              href={formatSocialUrl('linkedin', article.author.linkedin)}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="w-7 h-7 rounded-lg bg-white hover:bg-blue-50 text-slate-500 hover:text-blue-700 border border-slate-200 shadow-2xs flex items-center justify-center transition hover:scale-110"
                              title="LinkedIn"
                            >
                              <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                                <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.262-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
                              </svg>
                            </a>
                          )}
                          {article.author.youtube && (
                            <a
                              href={formatSocialUrl('youtube', article.author.youtube)}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="w-7 h-7 rounded-lg bg-white hover:bg-rose-50 text-slate-500 hover:text-rose-600 border border-slate-200 shadow-2xs flex items-center justify-center transition hover:scale-110"
                              title="YouTube"
                            >
                              <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                                <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                              </svg>
                            </a>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                )}

              </article>
            ) : (
              <div className="py-12 text-center text-slate-500">
                <p>Content unavailable or could not be loaded.</p>
                <Link href="/" className="mt-3 inline-block text-sm text-blue-600 font-medium hover:underline">
                  Return to Home
                </Link>
              </div>
            )}
          </section>

          {/* ================= RIGHT SIDEBAR WIDGET MATCHING LIVE JOB PAGE REFERENCE ================= */}
          <aside className="col-span-1 lg:col-span-4 xl:col-span-3 sticky top-20 self-start z-10 space-y-4 max-h-[calc(100vh-5.5rem)] overflow-y-auto">

            <div className="bg-[#f8f9fa] border border-slate-200 rounded-lg p-3.5 shadow-2xs">

              {/* Tab Header - 2 Equal 50% Tabs */}
              <div className="flex border-b border-slate-200 -mx-3.5 -mt-3.5 mb-3.5 bg-[#e9ecef]/50 rounded-t-lg overflow-hidden">
                <button
                  onClick={() => setSidebarTab('expiring')}
                  className={`flex-1 py-3 px-2 text-center text-xs sm:text-sm transition ${sidebarTab === 'expiring'
                    ? 'bg-[#e9ecef] text-slate-900 border-r border-slate-200 font-bold'
                    : 'bg-white/60 text-[#2563eb] hover:bg-white border-r border-slate-200 font-semibold'
                    }`}
                >
                  Jobs Expiring Soon
                </button>
                <button
                  onClick={() => setSidebarTab('mcq')}
                  className={`flex-1 py-3 px-2 text-center text-xs sm:text-sm transition ${sidebarTab === 'mcq'
                    ? 'bg-[#e9ecef] text-slate-900 font-bold'
                    : 'bg-white/60 text-[#2563eb] hover:bg-white font-semibold'
                    }`}
                >
                  MCQ Questions
                </button>
              </div>

              {sidebarTab === 'expiring' ? (
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-600 mb-2 px-0.5">
                    <span className="font-normal text-slate-600">
                      {expiringCount > 0
                        ? `${expiringCount} ${expiringCount === 1 ? 'Job is' : 'Jobs are'} expiring in 30 Days`
                        : '0 Jobs expiring in 30 Days'}
                    </span>
                    <div className="flex items-center space-x-1.5">
                      <Link href="/jobs-expiring-in-30-days" className="text-[#2563eb] font-medium hover:underline">View All</Link>
                      <span className="bg-[#2563eb] text-white text-[11px] font-semibold px-2 py-0.5 rounded flex items-center space-x-1">
                        <svg className="w-3 h-3 fill-current" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z" /></svg>
                        <span>Jobs</span>
                      </span>
                    </div>
                  </div>
                  <hr className="border-slate-200 mb-3.5" />

                  {/* Expiring Jobs List Rows */}
                  {sidebarLoading && expiringJobs.length === 0 ? (
                    <div className="space-y-3 py-1">
                      {[1, 2, 3, 4].map((n) => (
                        <div key={n} className="flex items-start space-x-3 animate-pulse">
                          <div className="w-[95px] h-[65px] rounded bg-slate-200 shrink-0" />
                          <div className="flex-1 space-y-2 py-1">
                            <div className="h-3 bg-slate-200 rounded w-full" />
                            <div className="h-2.5 bg-slate-200 rounded w-2/3" />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : expiringJobs.length > 0 ? (
                    <div className="space-y-3">
                      {expiringJobs.slice(0, 6).map((job, idx) => (
                        <div key={job.id || idx}>
                          <Link
                            href={`/job/${job.slug}`}
                            className="flex items-start space-x-3 group block transition"
                          >
                            <div className="w-[95px] h-[65px] shrink-0 rounded border border-slate-200 overflow-hidden bg-slate-100">
                              <img
                                src={job.image}
                                alt={job.title}
                                loading="lazy"
                                decoding="async"
                                className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                                onError={(e) => {
                                  if (!e.currentTarget.dataset.fallback) {
                                    e.currentTarget.dataset.fallback = 'true';
                                    e.currentTarget.src = '/logo.webp';
                                  } else {
                                    e.currentTarget.style.display = 'none';
                                  }
                                }}
                              />
                            </div>
                            <div className="flex-1 min-w-0 space-y-1">
                              <h4 className="text-xs sm:text-sm font-normal text-slate-900 group-hover:text-blue-600 line-clamp-2 leading-snug">
                                {job.title}
                              </h4>
                              <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                                <span className="text-slate-500 font-normal">
                                  Last Date: <span className="text-slate-600">{job.lastDate}</span>
                                </span>
                                <span className="text-[#2563eb] font-medium">Jobs</span>
                              </div>
                            </div>
                          </Link>
                          {idx < Math.min(expiringJobs.length, 6) - 1 && <hr className="border-slate-200/80 my-3" />}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="py-6 text-center text-xs text-slate-500">
                      <p>No active jobs available at this moment.</p>
                    </div>
                  )}
                </div>
              ) : (
                /* MCQ Tab Content */
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-600 mb-2 px-0.5">
                    <span className="font-normal text-slate-600">Daily Practice Questions</span>
                    <Link href="/mcq-questions" className="text-[#2563eb] font-medium hover:underline">View All</Link>
                  </div>
                  <hr className="border-slate-200 mb-3.5" />

                  <div className="space-y-3 text-xs">
                    <div className="py-2 border-b border-slate-200 space-y-1">
                      <span className="text-[10px] font-semibold text-blue-600 uppercase bg-blue-50 px-1.5 py-0.5 rounded">Indian Polity</span>
                      <p className="font-medium text-slate-800 leading-snug">Who presides over the joint sitting of the Parliament in India?</p>
                    </div>
                    <div className="py-2 border-b border-slate-200 space-y-1">
                      <span className="text-[10px] font-semibold text-amber-600 uppercase bg-amber-50 px-1.5 py-0.5 rounded">Current Affairs</span>
                      <p className="font-medium text-slate-800 leading-snug">Which state government recently launched the Youth Employment Scheme?</p>
                    </div>
                    <div className="py-2 space-y-1">
                      <span className="text-[10px] font-semibold text-emerald-600 uppercase bg-emerald-50 px-1.5 py-0.5 rounded">General Science</span>
                      <p className="font-medium text-slate-800 leading-snug">What is the SI unit of electric current intensity?</p>
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* Green Channel Join Banner Box matching Live Site */}
            <div className="bg-[#e6f7ef] border border-[#a3e6c5] rounded-lg p-3 text-center space-y-1.5">
              <p className="text-xs font-semibold text-emerald-900">
                सरकारी नौकरियों और GK अपडेट्स के लिए हमारे ग्रुप्स से जुड़ें:
              </p>
              <div className="flex items-center justify-center space-x-2 pt-1">
                <a
                  href="https://whatsapp.com/channel/0029Vb6sjZz0wajwDXcd5B0U"
                  target="_blank"
                  rel="noreferrer"
                  className="bg-[#25D366] hover:bg-[#20bd5a] text-white text-xs font-semibold px-3 py-1.5 rounded flex items-center space-x-1 shadow-2xs transition"
                >
                  <span>WhatsApp</span>
                </a>
                <a
                  href="https://t.me/educationmastersin"
                  target="_blank"
                  rel="noreferrer"
                  className="bg-[#0088cc] hover:bg-[#0077b5] text-white text-xs font-semibold px-3 py-1.5 rounded flex items-center space-x-1 shadow-2xs transition"
                >
                  <span>Telegram</span>
                </a>
              </div>
            </div>

          </aside>

        </div>
      </main>

      {/* Popup Modal for Internal Links in Text Editor */}
      <InternalLinkModal
        isOpen={internalLinkModal.isOpen}
        onClose={() => setInternalLinkModal((prev) => ({ ...prev, isOpen: false }))}
        targetUrl={internalLinkModal.targetUrl}
        targetWindow={internalLinkModal.targetWindow}
      />

      <Footer />
    </div>
  );
}
