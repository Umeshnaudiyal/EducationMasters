'use client';

import React, { useState, useEffect, useMemo } from 'react';
import { useSession } from 'next-auth/react';
import { useAuthModal } from '@/context/AuthModalContext';
import { useToast } from '@/context/ToastContext';
import {
  X,
  Sparkles,
  Brain,
  TrendingUp,
  Award,
  CheckCircle2,
  XCircle,
  Clock,
  Zap,
  Target,
  BarChart3,
  BookOpen,
  ArrowRight,
  RefreshCw,
  Printer,
  ChevronRight,
  AlertTriangle,
  Lightbulb,
  Layers,
  HelpCircle,
} from 'lucide-react';
import {
  AnimatedSparkles,
  AnimatedZap,
  AnimatedClock,
  AnimatedShieldCheck,
  AnimatedAward,
  AnimatedAiEye,
  AnimatedBrain,
  AnimatedRotateCcw,
} from '@/components/AnimatedIcons';

export default function EduAiAnalysisModal({
  isOpen,
  onClose,
  questions = [],
  userAnswers = {},
  stopwatchSeconds = 0,
  taxonomy = {},
  onJumpToQuestion,
}) {
  const { data: session } = useSession();
  const { openAuthModal } = useAuthModal();
  const { showToast } = useToast();

  const [analyzing, setAnalyzing] = useState(true);
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [analysisStep, setAnalysisStep] = useState(0);
  const [activeTab, setActiveTab] = useState('subjects'); // 'subjects' | 'insights' | 'matrix'

  // Registered users and 1-question minimum protection
  useEffect(() => {
    if (isOpen) {
      const answeredCount = Object.keys(userAnswers || {}).length;
      if (answeredCount === 0) {
        onClose?.();
        showToast({
          type: 'info',
          title: 'Answer a Question First',
          message: 'Please attempt at least 1 question below before running AI diagnostics.',
          duration: 5000,
        });
        return;
      }

      if (!session?.user) {
        onClose?.();
        openAuthModal({
          mode: 'register',
          mandatory: true,
          preventClose: true,
          title: '🧠 Free Sign In Required',
          subtitle: 'Edu AI diagnostics is available for registered students. Create a free account or log in to view detailed accuracy & speed analytics.',
        });
        showToast({
          type: 'info',
          title: 'Free Sign In Required',
          message: 'Please sign in or create a free account to access Edu AI Performance Analysis.',
          duration: 5000,
        });
      }
    }
  }, [isOpen, session, userAnswers, onClose, openAuthModal, showToast]);

  // Scanning steps for the 4.5s loader
  const scanningSteps = [
    { label: 'Reading question response logs & timestamps...', icon: Clock },
    { label: 'Segregating questions by subject & topic domains...', icon: Layers },
    { label: 'Calculating subject-wise accuracy & error matrices...', icon: BarChart3 },
    { label: 'Synthesizing Edu AI strengths, weaknesses & study roadmap...', icon: Brain },
    { label: 'Compiling interactive performance visualization graph...', icon: Sparkles },
  ];

  // 4.5s Animated Scanner on open
  useEffect(() => {
    if (!isOpen) return;

    setAnalyzing(true);
    setAnalysisProgress(0);
    setAnalysisStep(0);

    const startTime = Date.now();
    const duration = 4500; // 4.5 seconds

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(Math.round((elapsed / duration) * 100), 100);
      setAnalysisProgress(progress);

      if (progress < 22) setAnalysisStep(0);
      else if (progress < 45) setAnalysisStep(1);
      else if (progress < 70) setAnalysisStep(2);
      else if (progress < 90) setAnalysisStep(3);
      else setAnalysisStep(4);

      if (elapsed >= duration) {
        clearInterval(interval);
        setAnalyzing(false);
      }
    }, 60);

    return () => clearInterval(interval);
  }, [isOpen]);

  // Comprehensive Subject-Wise & Overall Performance Analytics Calculation
  const analyticsData = useMemo(() => {
    const total = questions.length;
    let attempted = 0;
    let correct = 0;
    let incorrect = 0;

    // Subject Grouping
    const subjectMap = {};

    questions.forEach((q, idx) => {
      const qId = q._id || q.sql_id || idx;
      const userSelected = userAnswers[qId];
      const isAttempted = userSelected !== undefined;

      // Extract correct answer index
      let correctIndex = -1;
      if (Array.isArray(q.options)) {
        correctIndex = q.options.findIndex((opt) => opt.is_correct);
      }
      if (correctIndex === -1 && q.correct_answer) {
        const match = String(q.correct_answer).match(/Option\s*([0-9]+)/i);
        if (match) correctIndex = parseInt(match[1], 10) - 1;
        else if (['A', 'B', 'C', 'D'].includes(String(q.correct_answer).trim().toUpperCase())) {
          correctIndex = String(q.correct_answer).trim().toUpperCase().charCodeAt(0) - 65;
        }
      }

      const isCorrect = isAttempted && userSelected === correctIndex;
      const isIncorrect = isAttempted && !isCorrect;

      if (isAttempted) {
        attempted += 1;
        if (isCorrect) correct += 1;
        else incorrect += 1;
      }

      // Determine subject name dynamically
      let subj =
        q.subject_name ||
        q.subject?.name ||
        q.topic_name ||
        q.topic?.name ||
        q.category ||
        '';

      if (!subj || subj.trim() === '') {
        // Derive subject from content or taxonomy
        const text = (q.question_text || q.question || '').toLowerCase();
        if (text.includes('constitution') || text.includes('article') || text.includes('president') || text.includes('parliament') || text.includes('court') || text.includes('amendment')) {
          subj = 'Indian Polity & Governance';
        } else if (text.includes('river') || text.includes('mountain') || text.includes('climate') || text.includes('soil') || text.includes('capital') || text.includes('ocean')) {
          subj = 'Geography & Environment';
        } else if (text.includes('king') || text.includes('dynasty') || text.includes('war') || text.includes('century') || text.includes('movement') || text.includes('mughal') || text.includes('british')) {
          subj = 'Indian & World History';
        } else if (text.includes('gravity') || text.includes('chemical') || text.includes('cell') || text.includes('energy') || text.includes('vitamin') || text.includes('acid') || text.includes('physics') || text.includes('biology')) {
          subj = 'General Science & Tech';
        } else if (text.includes('gdp') || text.includes('bank') || text.includes('inflation') || text.includes('budget') || text.includes('rbi') || text.includes('tax') || text.includes('economy')) {
          subj = 'Indian Economy & Commerce';
        } else if (text.includes('ratio') || text.includes('speed') || text.includes('percentage') || text.includes('number') || text.includes('triangle') || text.includes('equation')) {
          subj = 'Quantitative Aptitude';
        } else if (text.includes('pattern') || text.includes('series') || text.includes('analogy') || text.includes('blood') || text.includes('direction')) {
          subj = 'Logical Reasoning';
        } else {
          subj = taxonomy.name ? `${taxonomy.name}` : 'General Studies';
        }
      }

      if (!subjectMap[subj]) {
        subjectMap[subj] = {
          name: subj,
          total: 0,
          attempted: 0,
          correct: 0,
          incorrect: 0,
          questions: [],
        };
      }

      subjectMap[subj].total += 1;
      if (isAttempted) {
        subjectMap[subj].attempted += 1;
        if (isCorrect) subjectMap[subj].correct += 1;
        else subjectMap[subj].incorrect += 1;
      }
      subjectMap[subj].questions.push({
        index: idx + 1,
        id: qId,
        isAttempted,
        isCorrect,
        isIncorrect,
      });
    });

    const subjectsList = Object.values(subjectMap).map((s) => {
      const accuracy = s.attempted > 0 ? Math.round((s.correct / s.attempted) * 100) : 0;
      const coverage = s.total > 0 ? Math.round((s.attempted / s.total) * 100) : 0;
      
      let status = 'Unattempted';
      let statusColor = 'text-slate-500 bg-slate-100 border-slate-200';
      let progressColor = 'bg-slate-400';

      if (s.attempted > 0) {
        if (accuracy >= 80) {
          status = 'Mastered';
          statusColor = 'text-emerald-700 bg-emerald-50 border-emerald-200';
          progressColor = 'bg-emerald-500';
        } else if (accuracy >= 60) {
          status = 'Proficient';
          statusColor = 'text-blue-700 bg-blue-50 border-blue-200';
          progressColor = 'bg-blue-500';
        } else if (accuracy >= 40) {
          status = 'Needs Focus';
          statusColor = 'text-amber-700 bg-amber-50 border-amber-200';
          progressColor = 'bg-amber-500';
        } else {
          status = 'Critical Review';
          statusColor = 'text-rose-700 bg-rose-50 border-rose-200';
          progressColor = 'bg-rose-500';
        }
      }

      return {
        ...s,
        accuracy,
        coverage,
        status,
        statusColor,
        progressColor,
      };
    });

    // Sort: highest attempted & accuracy first
    subjectsList.sort((a, b) => b.total - a.total);

    const overallAccuracy = attempted > 0 ? Math.round((correct / attempted) * 100) : 0;
    const unattempted = total - attempted;
    const avgTimePerQuestion = attempted > 0 ? (stopwatchSeconds / attempted).toFixed(1) : 0;

    // AI Performance Rating
    let aiGrade = 'Beginner';
    let aiGradeColor = 'from-slate-600 to-slate-800';
    let aiVerdict = 'Complete more questions to generate deeper intelligence insights.';

    if (attempted > 0) {
      if (overallAccuracy >= 85 && attempted >= total * 0.4) {
        aiGrade = 'A+ Master';
        aiGradeColor = 'from-emerald-600 to-teal-700';
        aiVerdict = 'Phenomenal performance! High precision with exceptional subject mastery.';
      } else if (overallAccuracy >= 70) {
        aiGrade = 'A Proficient';
        aiGradeColor = 'from-blue-600 to-indigo-700';
        aiVerdict = 'Strong command over core topics. Minor polish on tricky concepts will make you unbeatable.';
      } else if (overallAccuracy >= 50) {
        aiGrade = 'B+ Intermediate';
        aiGradeColor = 'from-indigo-600 to-violet-700';
        aiVerdict = 'Good foundation. Focus on targeted revision in low-scoring subjects to boost your rank.';
      } else if (overallAccuracy >= 35) {
        aiGrade = 'C Developing';
        aiGradeColor = 'from-amber-600 to-orange-700';
        aiVerdict = 'Moderate accuracy. Recommended to re-attempt questions with step-by-step solutions.';
      } else {
        aiGrade = 'Needs Practice';
        aiGradeColor = 'from-rose-600 to-red-700';
        aiVerdict = 'High mistake ratio. We recommend reviewing fundamental explanations before re-testing.';
      }
    }

    // Identify Strongest & Weakest Subjects
    const attemptedSubjects = subjectsList.filter((s) => s.attempted > 0);
    const strongestSubject =
      attemptedSubjects.length > 0
        ? [...attemptedSubjects].sort((a, b) => b.accuracy - a.accuracy)[0]
        : null;
    const weakestSubject =
      attemptedSubjects.length > 0
        ? [...attemptedSubjects].sort((a, b) => a.accuracy - b.accuracy)[0]
        : null;

    return {
      total,
      attempted,
      correct,
      incorrect,
      unattempted,
      overallAccuracy,
      avgTimePerQuestion,
      aiGrade,
      aiGradeColor,
      aiVerdict,
      subjectsList,
      strongestSubject,
      weakestSubject,
    };
  }, [questions, userAnswers, stopwatchSeconds, taxonomy]);

  if (!isOpen) return null;

  const handlePrint = () => {
    if (typeof window !== 'undefined') window.print();
  };

  const handleReAnalyze = () => {
    setAnalyzing(true);
    setAnalysisProgress(0);
    setAnalysisStep(0);
    const startTime = Date.now();
    const duration = 3500;
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(Math.round((elapsed / duration) * 100), 100);
      setAnalysisProgress(progress);
      if (progress < 25) setAnalysisStep(0);
      else if (progress < 50) setAnalysisStep(1);
      else if (progress < 75) setAnalysisStep(2);
      else setAnalysisStep(3);

      if (elapsed >= duration) {
        clearInterval(interval);
        setAnalyzing(false);
      }
    }, 60);
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-2.5 sm:p-4 md:p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-300">
      
      {/* Background Click to dismiss */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Main Analysis Modal Card */}
      <div className="relative w-full max-w-4xl bg-white rounded-3xl shadow-[0_25px_80px_-15px_rgba(0,0,0,0.4)] border border-slate-200/90 overflow-hidden z-10 flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200">
        
        {/* Modal Top Bar */}
        <div className="relative px-5 sm:px-7 py-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-950 text-white flex items-center justify-between border-b border-indigo-900/50 shrink-0">
          
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-500 to-indigo-500 p-0.5 shadow-lg shadow-blue-500/30 flex items-center justify-center shrink-0">
              <div className="w-full h-full bg-slate-900/40 rounded-[14px] flex items-center justify-center">
                <AnimatedBrain size={20} className="text-blue-300" />
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black tracking-tight text-white flex items-center gap-2">
                  <span>Edu AI Performance Diagnostics</span>
                  <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-blue-500/30 text-blue-300 border border-blue-400/30">
                    AI v3.5
                  </span>
                </h3>
              </div>
              <p className="text-xs text-blue-200/80 font-medium">
                {taxonomy.name || 'MCQ Practice'} • Deep Subject Breakdown & Accuracy Graph
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {!analyzing && (
              <button
                type="button"
                onClick={handleReAnalyze}
                title="Re-run AI Analysis"
                className="group p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition cursor-pointer hidden sm:flex items-center gap-1.5 text-xs font-semibold"
              >
                <AnimatedRotateCcw size={14} className="text-white" />
                <span>Re-Analyze</span>
              </button>
            )}

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition cursor-pointer flex items-center justify-center"
              aria-label="Close"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Modal Content Scroll Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-7 bg-slate-50/50">
          
          {/* ========================================================================= */}
          {/* 1. PROFESSIONAL EDU AI SCANNING & LOADING STATE (4.5 SECONDS) */}
          {/* ========================================================================= */}
          {analyzing ? (
            <div className="py-12 sm:py-16 px-4 flex flex-col items-center justify-center text-center space-y-8 animate-in fade-in duration-300">
              
              {/* Futuristic AI Quantum Radar Animation */}
              <div className="relative w-32 h-32 flex items-center justify-center">
                
                {/* Outer Rotating Glowing Ring */}
                <div className="absolute inset-0 rounded-full border-2 border-dashed border-blue-400/40 animate-[spin_8s_linear_infinite]" />
                <div className="absolute inset-2 rounded-full border-2 border-blue-500/20 animate-[spin_4s_linear_infinite_reverse]" />
                
                {/* Pulsing Core Radar */}
                <div className="absolute inset-4 rounded-full bg-gradient-to-tr from-blue-600/20 via-indigo-600/20 to-purple-600/20 animate-pulse backdrop-blur-xs" />
                
                {/* Center Brain Icon */}
                <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 shadow-xl shadow-blue-500/30 flex items-center justify-center text-white z-10">
                  <Brain className="w-8 h-8 animate-bounce" />
                </div>

                {/* Scanning Laser Beam */}
                <div className="absolute -inset-1 rounded-full bg-gradient-to-t from-transparent via-blue-400/30 to-transparent animate-[spin_2s_linear_infinite] pointer-events-none" />
              </div>

              {/* Progress & Live AI Step Log */}
              <div className="max-w-md w-full space-y-4">
                <div className="space-y-1.5">
                  <h4 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center justify-center gap-2">
                    <Sparkles className="w-5 h-5 text-blue-600 animate-spin" />
                    <span>Edu AI is Analyzing Your Performance...</span>
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-500 font-medium h-6">
                    {scanningSteps[analysisStep]?.label}
                  </p>
                </div>

                {/* Progress Bar with Gradient & Percentage */}
                <div className="space-y-1.5">
                  <div className="w-full bg-slate-200 rounded-full h-3 overflow-hidden p-0.5 shadow-inner">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-blue-500 via-indigo-500 to-emerald-500 transition-all duration-100 ease-out shadow-sm"
                      style={{ width: `${analysisProgress}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-xs font-bold text-slate-500 px-1">
                    <span>Processing Neural Evaluation</span>
                    <span className="text-blue-600 font-mono font-black">{analysisProgress}%</span>
                  </div>
                </div>

                {/* Step Matrix Pills */}
                <div className="pt-2 grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {['Accuracy Logs', 'Subject Segregation', 'Speed Index', 'Strategic Insights'].map((stepName, i) => (
                    <div
                      key={stepName}
                      className={`p-2 rounded-xl text-[11px] font-bold border transition-all duration-200 flex items-center justify-center gap-1.5 ${
                        analysisStep >= i
                          ? 'bg-blue-50 border-blue-300 text-blue-700 shadow-2xs'
                          : 'bg-white border-slate-200 text-slate-400 opacity-60'
                      }`}
                    >
                      {analysisStep > i ? (
                        <CheckCircle2 size={12} className="text-emerald-600 shrink-0" />
                      ) : analysisStep === i ? (
                        <span className="w-2 h-2 rounded-full bg-blue-600 animate-ping shrink-0" />
                      ) : (
                        <span className="w-2 h-2 rounded-full bg-slate-300 shrink-0" />
                      )}
                      <span className="truncate">{stepName}</span>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          ) : (
            /* ========================================================================= */
            /* 2. COMPREHENSIVE AI PERFORMANCE & SUBJECT GRAPH DASHBOARD */
            /* ========================================================================= */
            <div className="space-y-6 animate-in fade-in duration-300">
              
              {/* Executive Overview Banner */}
              <div className={`rounded-2xl p-5 sm:p-6 bg-gradient-to-r ${analyticsData.aiGradeColor} text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-5 relative overflow-hidden`}>
                
                {/* Ambient Decorative Shapes */}
                <div className="absolute -right-10 -bottom-10 w-48 h-48 bg-white/10 rounded-full blur-2xl pointer-events-none" />
                <div className="absolute left-1/3 -top-10 w-32 h-32 bg-blue-400/20 rounded-full blur-xl pointer-events-none" />

                <div className="relative z-10 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-black uppercase tracking-wider text-white border border-white/30 flex items-center gap-1.5">
                      <Award size={14} className="text-amber-300" />
                      <span>{analyticsData.aiGrade}</span>
                    </span>
                    <span className="text-xs text-white/80 font-medium">
                      {analyticsData.attempted} of {analyticsData.total} Questions Analyzed
                    </span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                    {analyticsData.aiVerdict}
                  </h3>

                  <p className="text-xs sm:text-sm text-white/90 leading-relaxed max-w-xl">
                    {analyticsData.strongestSubject && (
                      <span>
                        🎯 <strong>Strongest Topic:</strong> {analyticsData.strongestSubject.name} ({analyticsData.strongestSubject.accuracy}% accuracy).{' '}
                      </span>
                    )}
                    {analyticsData.weakestSubject && analyticsData.weakestSubject.name !== analyticsData.strongestSubject?.name && (
                      <span>
                        ⚠️ <strong>Needs Review:</strong> {analyticsData.weakestSubject.name} ({analyticsData.weakestSubject.accuracy}% accuracy).
                      </span>
                    )}
                  </p>
                </div>

                {/* Score & Accuracy Big Badges */}
                <div className="relative z-10 flex items-center gap-3 shrink-0">
                  <div className="p-3.5 bg-white/15 backdrop-blur-md rounded-2xl border border-white/20 text-center min-w-[100px]">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-white/80 block">Accuracy</span>
                    <span className="text-2xl sm:text-3xl font-black tracking-tight text-white">{analyticsData.overallAccuracy}%</span>
                  </div>

                  <div className="p-3.5 bg-white/15 backdrop-blur-md rounded-2xl border border-white/20 text-center min-w-[100px]">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-white/80 block">Net Score</span>
                    <span className="text-2xl sm:text-3xl font-black tracking-tight text-amber-300">
                      {analyticsData.correct}/{analyticsData.attempted}
                    </span>
                  </div>
                </div>

              </div>

              {/* 4 Core Vital Metric Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                
                <div className="bg-white border border-slate-200/90 rounded-2xl p-3.5 shadow-xs flex flex-col justify-between hover:border-emerald-300 transition">
                  <div className="flex items-center justify-between text-slate-600 text-xs font-semibold">
                    <span>Correct Answers</span>
                    <CheckCircle2 size={16} className="text-emerald-600" />
                  </div>
                  <div className="mt-2 flex items-baseline gap-1.5">
                    <span className="text-2xl font-black text-emerald-600">{analyticsData.correct}</span>
                    <span className="text-xs text-slate-400">/ {analyticsData.total}</span>
                  </div>
                  <div className="mt-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md w-fit">
                    +{analyticsData.correct * 1} Marks
                  </div>
                </div>

                <div className="bg-white border border-slate-200/90 rounded-2xl p-3.5 shadow-xs flex flex-col justify-between hover:border-rose-300 transition">
                  <div className="flex items-center justify-between text-slate-600 text-xs font-semibold">
                    <span>Mistakes / Wrong</span>
                    <XCircle size={16} className="text-rose-600" />
                  </div>
                  <div className="mt-2 flex items-baseline gap-1.5">
                    <span className="text-2xl font-black text-rose-600">{analyticsData.incorrect}</span>
                    <span className="text-xs text-slate-400">questions</span>
                  </div>
                  <div className="mt-1 text-[11px] font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md w-fit">
                    Review Required
                  </div>
                </div>

                <div className="bg-white border border-slate-200/90 rounded-2xl p-3.5 shadow-xs flex flex-col justify-between hover:border-blue-300 transition">
                  <div className="flex items-center justify-between text-slate-600 text-xs font-semibold">
                    <span>Average Speed</span>
                    <Clock size={16} className="text-blue-600" />
                  </div>
                  <div className="mt-2 flex items-baseline gap-1.5">
                    <span className="text-2xl font-black text-blue-600">{analyticsData.avgTimePerQuestion}s</span>
                    <span className="text-xs text-slate-400">/ question</span>
                  </div>
                  <div className="mt-1 text-[11px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md w-fit">
                    Pace: {Number(analyticsData.avgTimePerQuestion) <= 15 ? '⚡ Lightning' : '🎯 Optimum'}
                  </div>
                </div>

                <div className="bg-white border border-slate-200/90 rounded-2xl p-3.5 shadow-xs flex flex-col justify-between hover:border-purple-300 transition">
                  <div className="flex items-center justify-between text-slate-600 text-xs font-semibold">
                    <span>Unattempted</span>
                    <HelpCircle size={16} className="text-slate-400" />
                  </div>
                  <div className="mt-2 flex items-baseline gap-1.5">
                    <span className="text-2xl font-black text-slate-700">{analyticsData.unattempted}</span>
                    <span className="text-xs text-slate-400">skipped</span>
                  </div>
                  <div className="mt-1 text-[11px] font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-md w-fit">
                    {Math.round((analyticsData.unattempted / analyticsData.total) * 100)}% of test
                  </div>
                </div>

              </div>

              {/* Segmented Tab Navigation for Analytics Sections */}
              <div className="flex p-1.5 bg-slate-200/80 rounded-2xl border border-slate-300/80 max-w-md mx-auto">
                <button
                  type="button"
                  onClick={() => setActiveTab('subjects')}
                  className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs sm:text-sm transition-all duration-200 flex items-center justify-center gap-1.5 cursor-pointer ${
                    activeTab === 'subjects'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <BarChart3 size={15} />
                  <span>Subject Graph</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('insights')}
                  className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs sm:text-sm transition-all duration-200 flex items-center justify-center gap-1.5 cursor-pointer ${
                    activeTab === 'insights'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Sparkles size={15} />
                  <span>AI Insights</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('matrix')}
                  className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs sm:text-sm transition-all duration-200 flex items-center justify-center gap-1.5 cursor-pointer ${
                    activeTab === 'matrix'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Layers size={15} />
                  <span>Questions Grid</span>
                </button>
              </div>

              {/* ================================================================= */}
              {/* TAB 1: SUBJECT-WISE PERFORMANCE & VISUAL GRAPH BREAKDOWN */}
              {/* ================================================================= */}
              {activeTab === 'subjects' && (
                <div className="space-y-4">
                  
                  {/* Visual Subject Accuracy Bar Comparison Graph */}
                  <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
                          <BarChart3 className="w-4 h-4 text-blue-600" />
                          <span>Subject-Wise Accuracy Comparison Graph</span>
                        </h4>
                        <p className="text-xs text-slate-500">
                          Real-time breakdown of your performance across each tested subject domain
                        </p>
                      </div>

                      <div className="hidden sm:flex items-center gap-3 text-xs font-semibold text-slate-500">
                        <span className="flex items-center gap-1.5">
                          <span className="w-3 h-3 rounded-full bg-emerald-500" /> &gt;75% High
                        </span>
                        <span className="flex items-center gap-1.5">
                          <span className="w-3 h-3 rounded-full bg-blue-500" /> 50-75% Medium
                        </span>
                        <span className="flex items-center gap-1.5">
                          <span className="w-3 h-3 rounded-full bg-rose-500" /> &lt;50% Low
                        </span>
                      </div>
                    </div>

                    {/* Interactive CSS Bar Charts for Subjects */}
                    <div className="space-y-3 pt-2">
                      {analyticsData.subjectsList.map((subj) => (
                        <div key={subj.name} className="space-y-1.5 p-3 rounded-xl bg-slate-50 border border-slate-200/70 hover:bg-slate-100/70 transition">
                          <div className="flex items-center justify-between text-xs font-bold">
                            <div className="flex items-center gap-2">
                              <BookOpen size={14} className="text-blue-600 shrink-0" />
                              <span className="text-slate-800 font-extrabold">{subj.name}</span>
                              <span className="text-[10px] text-slate-400 font-normal">
                                ({subj.total} Questions)
                              </span>
                            </div>

                            <div className="flex items-center gap-2">
                              <span className={`text-[10px] px-2 py-0.5 rounded-full border font-bold ${subj.statusColor}`}>
                                {subj.status}
                              </span>
                              <span className="font-mono font-black text-slate-900 text-sm">
                                {subj.accuracy}%
                              </span>
                            </div>
                          </div>

                          {/* Progress Bar with Multiple Colored Segments (Correct / Incorrect / Unattempted) */}
                          <div className="w-full bg-slate-200/80 rounded-full h-2.5 overflow-hidden flex shadow-inner">
                            {/* Correct Segment */}
                            <div
                              className="bg-emerald-500 h-full transition-all duration-500 ease-out"
                              style={{ width: `${(subj.correct / subj.total) * 100}%` }}
                              title={`${subj.correct} Correct`}
                            />
                            {/* Incorrect Segment */}
                            <div
                              className="bg-rose-500 h-full transition-all duration-500 ease-out"
                              style={{ width: `${(subj.incorrect / subj.total) * 100}%` }}
                              title={`${subj.incorrect} Incorrect`}
                            />
                          </div>

                          {/* Sub-metrics Pills */}
                          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-0.5">
                            <div className="flex items-center gap-3">
                              <span className="text-emerald-700 font-semibold">
                                ✓ {subj.correct} Correct
                              </span>
                              <span className="text-rose-600 font-semibold">
                                ✗ {subj.incorrect} Wrong
                              </span>
                              <span className="text-slate-500">
                                ⚪ {subj.total - subj.attempted} Skipped
                              </span>
                            </div>

                            <span className="text-slate-400 text-[10px]">
                              Attempted {subj.attempted}/{subj.total}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>

                  </div>

                </div>
              )}

              {/* ================================================================= */}
              {/* TAB 2: AI STRATEGIC INSIGHTS & STUDY PLAN */}
              {/* ================================================================= */}
              {activeTab === 'insights' && (
                <div className="space-y-4">
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    
                    {/* Strengths Card */}
                    <div className="bg-emerald-50/70 border border-emerald-200/90 rounded-2xl p-5 space-y-3">
                      <div className="flex items-center gap-2 text-emerald-800 font-extrabold text-sm sm:text-base">
                        <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                        <span>Identified Core Strengths</span>
                      </div>
                      
                      <ul className="space-y-2 text-xs sm:text-sm text-emerald-950 font-medium">
                        {analyticsData.strongestSubject ? (
                          <li className="flex items-start gap-2">
                            <span className="text-emerald-600 font-bold shrink-0">1.</span>
                            <span>
                              <strong>{analyticsData.strongestSubject.name}:</strong> High accuracy rate of <strong>{analyticsData.strongestSubject.accuracy}%</strong> with solid concept retention.
                            </span>
                          </li>
                        ) : null}

                        <li className="flex items-start gap-2">
                          <span className="text-emerald-600 font-bold shrink-0">2.</span>
                          <span>
                            <strong>Speed Efficiency:</strong> Answering at an average pace of <strong>{analyticsData.avgTimePerQuestion}s/question</strong> allows ample buffer time during final competitive exams.
                          </span>
                        </li>

                        <li className="flex items-start gap-2">
                          <span className="text-emerald-600 font-bold shrink-0">3.</span>
                          <span>
                            <strong>Decision Making:</strong> Demonstrated smart question selection by avoiding negative guesses on unclear questions.
                          </span>
                        </li>
                      </ul>
                    </div>

                    {/* Areas for Improvement Card */}
                    <div className="bg-amber-50/70 border border-amber-200/90 rounded-2xl p-5 space-y-3">
                      <div className="flex items-center gap-2 text-amber-800 font-extrabold text-sm sm:text-base">
                        <AlertTriangle className="w-5 h-5 text-amber-600" />
                        <span>High-Yield Revision Focus</span>
                      </div>
                      
                      <ul className="space-y-2 text-xs sm:text-sm text-amber-950 font-medium">
                        {analyticsData.weakestSubject && analyticsData.weakestSubject.accuracy < 70 ? (
                          <li className="flex items-start gap-2">
                            <span className="text-amber-600 font-bold shrink-0">1.</span>
                            <span>
                              <strong>Priority Focus in {analyticsData.weakestSubject.name}:</strong> Accuracy was <strong>{analyticsData.weakestSubject.accuracy}%</strong> with {analyticsData.weakestSubject.incorrect} mistakes. Recommended to re-read key NCERT/Standard notes.
                            </span>
                          </li>
                        ) : null}

                        <li className="flex items-start gap-2">
                          <span className="text-amber-600 font-bold shrink-0">2.</span>
                          <span>
                            <strong>Question Explanations:</strong> Review all {analyticsData.incorrect} incorrect solutions thoroughly to prevent recurring traps in similar examination patterns.
                          </span>
                        </li>

                        <li className="flex items-start gap-2">
                          <span className="text-amber-600 font-bold shrink-0">3.</span>
                          <span>
                            <strong>Mock Test Practice:</strong> Try attempting full-length timed mock tests on Education Masters to build real-time exam stamina.
                          </span>
                        </li>
                      </ul>
                    </div>

                  </div>

                  {/* AI Smart Action Roadmap */}
                  <div className="bg-white rounded-2xl border border-slate-200/90 p-5 space-y-3">
                    <div className="flex items-center gap-2 text-slate-900 font-extrabold text-sm sm:text-base">
                      <Lightbulb className="w-5 h-5 text-blue-600" />
                      <span>Edu AI Next Steps Roadmap</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                      <div className="p-3.5 rounded-xl bg-blue-50/80 border border-blue-200/80 space-y-1">
                        <span className="text-xs font-bold text-blue-700 block">Step 1 • Review Explanations</span>
                        <p className="text-xs text-slate-600">
                          Use the Question Matrix tab to review detailed answer explanations for all mistakes.
                        </p>
                      </div>

                      <div className="p-3.5 rounded-xl bg-indigo-50/80 border border-indigo-200/80 space-y-1">
                        <span className="text-xs font-bold text-indigo-700 block">Step 2 • Subject Re-Test</span>
                        <p className="text-xs text-slate-600">
                          Re-attempt weak subject questions with zero time pressure to solidify fundamentals.
                        </p>
                      </div>

                      <div className="p-3.5 rounded-xl bg-emerald-50/80 border border-emerald-200/80 space-y-1">
                        <span className="text-xs font-bold text-emerald-700 block">Step 3 • Track Improvement</span>
                        <p className="text-xs text-slate-600">
                          Re-run this AI Analysis after practicing to observe your accuracy graph jump from {analyticsData.overallAccuracy}% to 90%+.
                        </p>
                      </div>
                    </div>
                  </div>

                </div>
              )}

              {/* ================================================================= */}
              {/* TAB 3: INTERACTIVE QUESTION MATRIX GRID (JUMP TO REVIEW) */}
              {/* ================================================================= */}
              {activeTab === 'matrix' && (
                <div className="bg-white rounded-2xl border border-slate-200/90 p-5 space-y-4">
                  
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
                    <div>
                      <h4 className="text-sm sm:text-base font-extrabold text-slate-900">
                        Interactive Question Response Grid
                      </h4>
                      <p className="text-xs text-slate-500">
                        Click on any question number to close this dialog and immediately jump to review it on the page
                      </p>
                    </div>

                    <div className="flex items-center gap-3 text-xs font-semibold">
                      <span className="flex items-center gap-1 text-emerald-700">
                        <span className="w-3 h-3 rounded bg-emerald-500 inline-block" /> Correct ({analyticsData.correct})
                      </span>
                      <span className="flex items-center gap-1 text-rose-700">
                        <span className="w-3 h-3 rounded bg-rose-500 inline-block" /> Wrong ({analyticsData.incorrect})
                      </span>
                      <span className="flex items-center gap-1 text-slate-600">
                        <span className="w-3 h-3 rounded bg-slate-200 inline-block" /> Skipped ({analyticsData.unattempted})
                      </span>
                    </div>
                  </div>

                  {/* Question Buttons Matrix */}
                  <div className="grid grid-cols-5 sm:grid-cols-7 md:grid-cols-10 gap-2">
                    {questions.map((q, idx) => {
                      const qId = q._id || q.sql_id || idx;
                      const selected = userAnswers[qId];
                      const isAttempted = selected !== undefined;

                      let correctIndex = -1;
                      if (Array.isArray(q.options)) {
                        correctIndex = q.options.findIndex((opt) => opt.is_correct);
                      }
                      if (correctIndex === -1 && q.correct_answer) {
                        const match = String(q.correct_answer).match(/Option\s*([0-9]+)/i);
                        if (match) correctIndex = parseInt(match[1], 10) - 1;
                        else if (['A', 'B', 'C', 'D'].includes(String(q.correct_answer).trim().toUpperCase())) {
                          correctIndex = String(q.correct_answer).trim().toUpperCase().charCodeAt(0) - 65;
                        }
                      }

                      const isCorrect = isAttempted && selected === correctIndex;
                      const isIncorrect = isAttempted && !isCorrect;

                      return (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            onClose();
                            if (onJumpToQuestion) onJumpToQuestion(idx);
                          }}
                          className={`p-2.5 rounded-xl font-mono font-bold text-xs sm:text-sm border transition-all duration-150 flex flex-col items-center justify-center gap-0.5 cursor-pointer hover:scale-105 active:scale-95 shadow-2xs ${
                            isCorrect
                              ? 'bg-emerald-500 border-emerald-600 text-white shadow-emerald-500/20'
                              : isIncorrect
                                ? 'bg-rose-500 border-rose-600 text-white shadow-rose-500/20'
                                : 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200'
                          }`}
                          title={`Question ${idx + 1}: ${
                            isCorrect ? 'Correct Answer' : isIncorrect ? 'Incorrect Answer' : 'Unattempted'
                          }`}
                        >
                          <span>Q{idx + 1}</span>
                          <span className="text-[10px] font-sans font-medium opacity-90">
                            {isCorrect ? '✓' : isIncorrect ? '✗' : '—'}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                </div>
              )}

            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="px-5 sm:px-7 py-3.5 bg-white border-t border-slate-200/80 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          
          <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
            <Brain size={15} className="text-blue-600 shrink-0" />
            <span>Edu AI Real-Time Performance Engine • Education Masters</span>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={handlePrint}
              className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs sm:text-sm font-bold transition flex items-center gap-1.5 cursor-pointer"
            >
              <Printer size={15} />
              <span>Print Report</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-bold shadow-md shadow-blue-500/20 transition cursor-pointer"
            >
              Back to Practice
            </button>
          </div>

        </div>

      </div>

    </div>
  );
}
